# Financial Parallelverse
Test a big purchase against five possible futures before you commit.

Features: accounts (scrypt passwords, lockout, guest demo, per-user data), live counters + activity feed + daily streak, Can-I-buy-it (cash/wait/cheaper/EMI with real cost, job-loss runway, credit estimate), What-if futures chart, EMI tracker with .ics reminders, light/dark auto, mobile tab bar.

Run: pip install -r requirements.txt && streamlit run frontend_streamlit/app.py
API (optional): uvicorn backend.app.main:app --port 8000  (Bearer-token auth, docs at /api/docs)
Tests: python -m pytest backend/tests

Deploy: push to GitHub, create a Streamlit Community Cloud app with main file frontend_streamlit/app.py.
Storage there is ephemeral (accounts reset on restart); set PARALLELVERSE_DB to a persistent disk path for permanent data.
Credit score numbers are estimates, not a bureau score.
