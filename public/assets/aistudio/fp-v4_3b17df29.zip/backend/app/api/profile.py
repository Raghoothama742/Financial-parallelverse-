from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import FinancialProfile
from ..schemas import FinancialProfileUpdate, FinancialProfileResponse
from ..deps import get_current_user
from ..models import User
from ..services import auth_service
from ..services.financial_engine import FinancialEngine

router = APIRouter(prefix="/profile", tags=["Financial Profile"])

# Fields added after v1.0. Only written when the client actually sends them, so an
# older client that omits them can never silently reset the user's saved values.
_OPTIONAL_FIELDS = ("income_growth_pct", "investment_return_pct", "credit_score")

def _ensure_profile(db: Session, user: User) -> FinancialProfile:
    return auth_service.get_or_create_profile(db, user)

def _to_response(profile: FinancialProfile) -> FinancialProfileResponse:
    metrics = FinancialEngine.calculate_profile_metrics(
        monthly_income=profile.monthly_income,
        current_savings=profile.current_savings,
        essential_expenses=profile.essential_expenses,
        discretionary_expenses=profile.discretionary_expenses,
        existing_debt_emi=profile.existing_debt_emi,
        emergency_fund_target=profile.emergency_fund_target
    )
    return FinancialProfileResponse(
        id=profile.id,
        full_name=profile.full_name,
        monthly_income=profile.monthly_income,
        current_savings=profile.current_savings,
        essential_expenses=profile.essential_expenses,
        discretionary_expenses=profile.discretionary_expenses,
        existing_debt_emi=profile.existing_debt_emi,
        emergency_fund_target=profile.emergency_fund_target,
        income_growth_pct=profile.income_growth_pct,
        investment_return_pct=profile.investment_return_pct,
        credit_score=profile.credit_score,
        planned_purchase_name=profile.planned_purchase_name,
        planned_purchase_amount=profile.planned_purchase_amount,
        planned_purchase_month=profile.planned_purchase_month,
        free_cash_flow=metrics["free_cash_flow"],
        savings_rate_pct=metrics["savings_rate_pct"],
        debt_to_income_pct=metrics["debt_to_income_pct"],
        months_of_runway=metrics["months_of_runway"],
        health_score=metrics["health_score"],
        health_label=metrics["health_label"],
        updated_at=profile.updated_at
    )

@router.get("", response_model=FinancialProfileResponse)
def get_profile(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    return _to_response(_ensure_profile(db, user))

@router.put("", response_model=FinancialProfileResponse)
def update_profile(data: FinancialProfileUpdate, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    profile = _ensure_profile(db, user)
    profile.onboarded = 1

    profile.full_name = data.full_name
    profile.monthly_income = data.monthly_income
    profile.current_savings = data.current_savings
    profile.essential_expenses = data.essential_expenses
    profile.discretionary_expenses = data.discretionary_expenses
    profile.existing_debt_emi = data.existing_debt_emi
    profile.emergency_fund_target = data.emergency_fund_target
    profile.planned_purchase_name = data.planned_purchase_name
    profile.planned_purchase_amount = data.planned_purchase_amount
    profile.planned_purchase_month = data.planned_purchase_month

    for field in _OPTIONAL_FIELDS:
        if field in data.model_fields_set:
            setattr(profile, field, getattr(data, field))

    db.commit()
    db.refresh(profile)
    return _to_response(profile)
