from fastapi import APIRouter, Depends, Header, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session
from typing import Optional

from ..database import get_db
from ..deps import get_current_user
from ..models import User
from ..services import activity, auth_service

router = APIRouter(prefix="/auth", tags=["Accounts"])


class RegisterRequest(BaseModel):
    email: str
    name: str = Field(default="", max_length=100)
    password: str


class LoginRequest(BaseModel):
    email: str
    password: str


def _user_out(user: User) -> dict:
    return {"id": user.id, "name": user.name, "email": user.email, "is_guest": user.is_guest}


@router.post("/register")
def register(req: RegisterRequest, db: Session = Depends(get_db)):
    try:
        user = auth_service.register(db, req.email, req.name, req.password)
    except auth_service.AuthError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return {"token": auth_service.create_session(db, user), "user": _user_out(user)}


@router.post("/login")
def login(req: LoginRequest, db: Session = Depends(get_db)):
    try:
        user = auth_service.authenticate(db, req.email, req.password)
    except auth_service.AuthError as e:
        raise HTTPException(status_code=401, detail=str(e))
    return {"token": auth_service.create_session(db, user), "user": _user_out(user)}


@router.post("/guest")
def guest(db: Session = Depends(get_db)):
    user = auth_service.create_guest(db)
    return {"token": auth_service.create_session(db, user), "user": _user_out(user)}


@router.post("/logout")
def logout(authorization: Optional[str] = Header(default=None), db: Session = Depends(get_db)):
    if authorization and authorization.lower().startswith("bearer "):
        auth_service.revoke_session(db, authorization[7:].strip())
    return {"status": "signed out"}


@router.get("/me")
def me(user: User = Depends(get_current_user)):
    return _user_out(user)


@router.get("/stats/live", tags=["Live tracker"])
def live(db: Session = Depends(get_db)):
    """Public, anonymous aggregates for the live counters."""
    return activity.live_stats(db)
