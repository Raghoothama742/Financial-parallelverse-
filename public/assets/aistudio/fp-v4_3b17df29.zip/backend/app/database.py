from sqlalchemy import create_engine, inspect, text
from sqlalchemy.orm import declarative_base, sessionmaker
from .config import DATABASE_URL

engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False}
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# Columns added after v1.0. `create_all` never alters an existing table, so an
# older database file would be missing them and every profile query would crash.
# Each entry: (table, column, SQL type, SQL default).
_ADDED_COLUMNS = [
    ("financial_profiles", "income_growth_pct", "FLOAT", "5.0"),
    ("financial_profiles", "investment_return_pct", "FLOAT", "6.0"),
    ("financial_profiles", "credit_score", "INTEGER", "750"),
    ("financial_profiles", "onboarded", "INTEGER", "1"),
    # Account ownership. NULL = "legacy row from before accounts"; the first real user to
    # sign up inherits those rows (see auth_service.register).
    ("financial_profiles", "user_id", "INTEGER", None),
    ("installment_plans", "user_id", "INTEGER", None),
]

def migrate_schema(bind=None) -> list:
    """Adds any missing columns to existing tables. Safe to run on every start.

    Returns the list of "table.column" names that were added.
    """
    bind = bind or engine
    added = []
    insp = inspect(bind)
    existing_tables = set(insp.get_table_names())
    with bind.begin() as conn:
        for table, column, sql_type, default in _ADDED_COLUMNS:
            if table not in existing_tables:
                continue  # create_all will build it with the column included
            present = {c["name"] for c in insp.get_columns(table)}
            if column not in present:
                ddl = f"ALTER TABLE {table} ADD COLUMN {column} {sql_type}"
                if default is not None:
                    ddl += f" NOT NULL DEFAULT {default}"
                conn.execute(text(ddl))
                added.append(f"{table}.{column}")
    return added

def init_db():
    from . import models
    Base.metadata.create_all(bind=engine)
    migrate_schema(engine)
