"""
Accounts, passwords and sign-in sessions. Standard library only (no extra dependencies).

Security choices
----------------
* Passwords: scrypt (memory-hard) with a random 16-byte salt per user. Stored as
  "scrypt$n$r$p$salt$hash". Compared in constant time.
* Sign-in tokens: 32 random bytes (URL-safe). Only the SHA-256 of a token is stored, so a
  leaked database cannot be replayed as live sessions.
* Brute force: 5 wrong passwords lock that account for 5 minutes. Unknown emails take the
  same time and show the same message as wrong passwords (no account enumeration).
* Guests get a throwaway account with no email or password and 24-hour sessions.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import os
import re
import secrets
from datetime import datetime, timedelta
from typing import Optional, Tuple

from sqlalchemy.orm import Session

from ..models import (
    ActivityEvent, AuthSession, FinancialProfile, Heartbeat, InstallmentPayment, InstallmentPlan, User,
)

SCRYPT_N, SCRYPT_R, SCRYPT_P = 2 ** 14, 8, 1
MAX_FAILED_ATTEMPTS = 5
LOCKOUT = timedelta(minutes=5)
SESSION_LIFETIME = timedelta(days=30)
GUEST_SESSION_LIFETIME = timedelta(hours=24)
MIN_PASSWORD_LEN = 8

_EMAIL_RE = re.compile(r"^[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}$")
GENERIC_LOGIN_ERROR = "Wrong email or password."


class AuthError(Exception):
    """A problem the user can fix. The message is safe to show on screen."""


# ------------------------------------------------------------------ passwords
def hash_password(password: str) -> str:
    salt = os.urandom(16)
    digest = hashlib.scrypt(password.encode("utf-8"), salt=salt, n=SCRYPT_N, r=SCRYPT_R, p=SCRYPT_P, dklen=32)
    b64 = lambda b: base64.b64encode(b).decode("ascii")
    return f"scrypt${SCRYPT_N}${SCRYPT_R}${SCRYPT_P}${b64(salt)}${b64(digest)}"


def verify_password(password: str, stored: Optional[str]) -> bool:
    """Constant-time check. A missing/garbled hash still does the same work, then returns False."""
    try:
        scheme, n, r, p, salt_b64, hash_b64 = (stored or "").split("$")
        if scheme != "scrypt":
            raise ValueError
        salt, expected = base64.b64decode(salt_b64), base64.b64decode(hash_b64)
        n, r, p = int(n), int(r), int(p)
    except Exception:
        salt, expected, n, r, p = b"\0" * 16, b"\0" * 32, SCRYPT_N, SCRYPT_R, SCRYPT_P
        hashlib.scrypt(password.encode("utf-8"), salt=salt, n=n, r=r, p=p, dklen=32)   # burn the same time
        return False
    got = hashlib.scrypt(password.encode("utf-8"), salt=salt, n=n, r=r, p=p, dklen=len(expected))
    return hmac.compare_digest(got, expected)


def normalize_email(email: str) -> str:
    return (email or "").strip().lower()


def validate_email(email: str) -> str:
    email = normalize_email(email)
    if len(email) > 254 or not _EMAIL_RE.match(email):
        raise AuthError("Please enter a valid email address.")
    return email


def validate_password(password: str) -> None:
    if len(password or "") < MIN_PASSWORD_LEN:
        raise AuthError(f"Use at least {MIN_PASSWORD_LEN} characters for your password.")
    if len(password) > 200:
        raise AuthError("That password is too long (200 characters max).")
    if password.lower() in {"password", "12345678", "123456789", "qwertyui", "iloveyou", "password1"}:
        raise AuthError("That password is too easy to guess. Try a longer phrase.")


def password_strength(password: str) -> Tuple[int, str]:
    """0-4 score + label, for the strength meter (guidance only, not enforcement)."""
    if not password:
        return 0, ""
    score = 0
    score += len(password) >= 8
    score += len(password) >= 12
    score += bool(re.search(r"[a-z]", password)) and bool(re.search(r"[A-Z]", password))
    score += bool(re.search(r"\d", password)) and bool(re.search(r"[^A-Za-z0-9]", password))
    return int(score), ["Weak", "Okay", "Good", "Strong", "Very strong"][int(score)]


# ------------------------------------------------------------------ sessions
def _hash_token(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def create_session(db: Session, user: User) -> str:
    token = secrets.token_urlsafe(32)
    life = GUEST_SESSION_LIFETIME if user.is_guest else SESSION_LIFETIME
    db.add(AuthSession(token_hash=_hash_token(token), user_id=user.id, expires_at=datetime.utcnow() + life))
    db.commit()
    return token


def user_from_token(db: Session, token: Optional[str]) -> Optional[User]:
    if not token or len(token) > 200:
        return None
    sess = db.query(AuthSession).filter(AuthSession.token_hash == _hash_token(token)).first()
    if not sess:
        return None
    if sess.expires_at < datetime.utcnow():
        db.delete(sess)
        db.commit()
        return None
    return db.query(User).filter(User.id == sess.user_id).first()


def revoke_session(db: Session, token: Optional[str]) -> None:
    if not token:
        return
    db.query(AuthSession).filter(AuthSession.token_hash == _hash_token(token)).delete()
    db.commit()


def purge_expired(db: Session) -> int:
    """Removes dead sessions, stale heartbeats and expired guest accounts with all their data."""
    now = datetime.utcnow()
    n = db.query(AuthSession).filter(AuthSession.expires_at < now).delete()
    db.query(Heartbeat).filter(Heartbeat.last_seen < now - timedelta(days=1)).delete()
    old_guests = db.query(User).filter(User.is_guest.is_(True), User.created_at < now - GUEST_SESSION_LIFETIME).all()
    for g in old_guests:
        delete_user_data(db, g.id, commit=False)
        db.delete(g)
    db.commit()
    return n + len(old_guests)


# ------------------------------------------------------------------ accounts
def register(db: Session, email: str, name: str, password: str) -> User:
    email = validate_email(email)
    validate_password(password)
    name = (name or "").strip()[:100] or email.split("@")[0]
    if db.query(User).filter(User.email == email).first():
        raise AuthError("An account with this email already exists. Try signing in.")

    user = User(email=email, name=name, password_hash=hash_password(password), is_guest=False)
    db.add(user)
    db.flush()

    # The first real account inherits any data created before accounts existed.
    is_first_real_user = db.query(User).filter(User.is_guest.is_(False), User.id != user.id).count() == 0
    if is_first_real_user:
        db.query(FinancialProfile).filter(FinancialProfile.user_id.is_(None)).update({"user_id": user.id})
        db.query(InstallmentPlan).filter(InstallmentPlan.user_id.is_(None)).update({"user_id": user.id})
    db.add(ActivityEvent(user_id=user.id, kind="signup"))
    db.commit()
    return user


def authenticate(db: Session, email: str, password: str) -> User:
    email = normalize_email(email)
    user = db.query(User).filter(User.email == email).first() if email else None
    now = datetime.utcnow()

    if user and user.locked_until and user.locked_until > now:
        mins = max(1, int((user.locked_until - now).total_seconds() // 60) + 1)
        raise AuthError(f"Too many wrong attempts. Try again in {mins} minute{'s' if mins != 1 else ''}.")

    ok = verify_password(password or "", user.password_hash if user else None)   # same work either way
    if not user or not ok:
        if user:
            user.failed_attempts = (user.failed_attempts or 0) + 1
            if user.failed_attempts >= MAX_FAILED_ATTEMPTS:
                user.locked_until = now + LOCKOUT
                user.failed_attempts = 0
            db.commit()
        raise AuthError(GENERIC_LOGIN_ERROR)

    user.failed_attempts, user.locked_until, user.last_login = 0, None, now
    db.add(ActivityEvent(user_id=user.id, kind="login"))
    db.commit()
    return user


def create_guest(db: Session) -> User:
    """One-click demo account, pre-filled with believable numbers. Auto-deleted after 24 hours."""
    user = User(email=None, name="Guest", password_hash=None, is_guest=True)
    db.add(user)
    db.flush()
    db.add(FinancialProfile(
        user_id=user.id, full_name="Guest", monthly_income=75000.0, current_savings=120000.0,
        essential_expenses=32000.0, discretionary_expenses=15000.0, existing_debt_emi=8000.0,
        emergency_fund_target=150000.0, income_growth_pct=8.0, investment_return_pct=6.0, credit_score=750,
        planned_purchase_name="Laptop", planned_purchase_amount=70000.0, planned_purchase_month=1, onboarded=1))
    db.add(ActivityEvent(user_id=user.id, kind="guest"))
    db.commit()
    return user


def get_or_create_profile(db: Session, user: User) -> FinancialProfile:
    p = db.query(FinancialProfile).filter(FinancialProfile.user_id == user.id).first()
    if not p:
        # Real users start on gentle starter numbers and are nudged to make them their own.
        p = FinancialProfile(user_id=user.id, full_name=user.name, onboarded=1 if user.is_guest else 0)
        db.add(p)
        db.commit()
        db.refresh(p)
    return p


def delete_user_data(db: Session, user_id: int, commit: bool = True) -> None:
    for plan in db.query(InstallmentPlan).filter(InstallmentPlan.user_id == user_id).all():
        db.query(InstallmentPayment).filter(InstallmentPayment.installment_id == plan.id).delete()
        db.delete(plan)
    db.query(FinancialProfile).filter(FinancialProfile.user_id == user_id).delete()
    db.query(AuthSession).filter(AuthSession.user_id == user_id).delete()
    db.query(Heartbeat).filter(Heartbeat.user_id == user_id).update({"user_id": None})
    db.query(ActivityEvent).filter(ActivityEvent.user_id == user_id).update({"user_id": None})  # keep counters, drop identity
    if commit:
        db.commit()


def delete_account(db: Session, user: User) -> None:
    delete_user_data(db, user.id, commit=False)
    db.delete(user)
    db.commit()


def change_password(db: Session, user: User, current: str, new: str) -> None:
    if not verify_password(current or "", user.password_hash):
        raise AuthError("Your current password is not right.")
    validate_password(new)
    user.password_hash = hash_password(new)
    db.query(AuthSession).filter(AuthSession.user_id == user.id).delete()   # sign out every other device
    db.commit()
