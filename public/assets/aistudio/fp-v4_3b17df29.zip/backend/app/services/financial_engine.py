from typing import Dict, Any
from .emi_calculator import round_curr

def _clamp01(x: float) -> float:
    return max(0.0, min(1.0, x))

class FinancialEngine:
    @staticmethod
    def calculate_profile_metrics(
        monthly_income: float,
        current_savings: float,
        essential_expenses: float,
        discretionary_expenses: float,
        existing_debt_emi: float,
        emergency_fund_target: float
    ) -> Dict[str, Any]:
        """Calculates core baseline financial indicators."""
        total_monthly_outflows = round_curr(essential_expenses + discretionary_expenses + existing_debt_emi)
        free_cash_flow = round_curr(monthly_income - total_monthly_outflows)

        savings_rate = 0.0
        if monthly_income > 0:
            savings_rate = round_curr((free_cash_flow / monthly_income) * 100.0)

        debt_to_income = 0.0
        if monthly_income > 0:
            debt_to_income = round_curr((existing_debt_emi / monthly_income) * 100.0)

        burn_rate = essential_expenses + existing_debt_emi
        runway_months = round_curr(current_savings / burn_rate) if burn_rate > 0 else 99.0

        emergency_coverage_pct = 0.0
        if emergency_fund_target > 0:
            emergency_coverage_pct = round_curr((current_savings / emergency_fund_target) * 100.0)

        health = FinancialEngine.money_health_score(
            savings_rate_pct=savings_rate,
            runway_months=runway_months,
            debt_to_income_pct=debt_to_income,
            emergency_coverage_pct=emergency_coverage_pct,
        )

        return {
            "free_cash_flow": free_cash_flow,
            "total_monthly_outflows": total_monthly_outflows,
            "savings_rate_pct": savings_rate,
            "debt_to_income_pct": debt_to_income,
            "months_of_runway": runway_months,
            "emergency_coverage_pct": emergency_coverage_pct,
            "is_cash_flow_positive": free_cash_flow >= 0,
            "health_score": health["score"],
            "health_label": health["label"],
            "health_breakdown": health["breakdown"],
        }

    @staticmethod
    def money_health_score(
        savings_rate_pct: float,
        runway_months: float,
        debt_to_income_pct: float,
        emergency_coverage_pct: float,
    ) -> Dict[str, Any]:
        """
        One 0-100 number for "how am I doing?", built from four things a person
        can actually act on. Each part earns points up to its weight:

          Saving habit      30 pts   0% saved = 0 pts, 20%+ saved = full
          Safety net        30 pts   0 months = 0 pts, 6+ months = full
          Debt load         25 pts   50%+ of income to EMIs = 0, 15% or less = full
          Emergency fund    15 pts   share of your emergency target already saved
        """
        saving = _clamp01(savings_rate_pct / 20.0) * 30.0
        safety = _clamp01(runway_months / 6.0) * 30.0
        debt = _clamp01((50.0 - debt_to_income_pct) / 35.0) * 25.0
        fund = _clamp01(emergency_coverage_pct / 100.0) * 15.0

        score = int(round(saving + safety + debt + fund))
        if score >= 80:
            label = "Strong"
        elif score >= 60:
            label = "Healthy"
        elif score >= 40:
            label = "Fair"
        else:
            label = "Needs care"

        return {
            "score": score,
            "label": label,
            "breakdown": {
                "saving_habit": {"points": round(saving, 1), "max": 30},
                "safety_net": {"points": round(safety, 1), "max": 30},
                "debt_load": {"points": round(debt, 1), "max": 25},
                "emergency_fund": {"points": round(fund, 1), "max": 15},
            },
        }

    @staticmethod
    def job_loss_runway(
        current_savings: float,
        essential_expenses: float,
        existing_debt_emi: float,
        upfront_purchase_cost: float = 0.0,
        new_emi: float = 0.0,
        new_emi_months: int = 0,
        investment_return_pct: float = 0.0,
        max_months: int = 120,
    ) -> float:
        """
        "If my income stopped today, how many months could I last?"

        Assumes zero income and that you cut every discretionary expense, so only
        essentials, existing EMIs and any new EMI still have to be paid. Savings
        keep earning the investment return while they last. A purchase made today
        first reduces savings by its upfront cost. Returns months (fractional);
        99.0 means "outlasts the whole 10-year look-ahead".
        """
        balance = current_savings - upfront_purchase_cost
        if balance <= 0:
            return 0.0

        monthly_rate = (investment_return_pct / 100.0) / 12.0
        months = 0.0
        for m in range(1, max_months + 1):
            need = essential_expenses + existing_debt_emi + (new_emi if m <= new_emi_months else 0.0)
            available = balance + max(0.0, balance) * monthly_rate
            if need <= 0:
                return 99.0
            if available >= need:
                balance = available - need
                months += 1.0
            else:
                months += max(0.0, available) / need
                return round_curr(months)
        return 99.0
