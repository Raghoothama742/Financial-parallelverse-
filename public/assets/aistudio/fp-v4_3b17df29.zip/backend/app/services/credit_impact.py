from typing import Dict, Any
from .emi_calculator import round_curr

# ---------------------------------------------------------------------------
# Credit-score impact ESTIMATOR.
#
# This is a transparent rule of thumb, NOT a bureau (CIBIL/Experian) score.
# Every constant below is a rough, commonly-quoted magnitude so the user can see
# the *direction and size* of the effect of taking a new loan. Real scores depend
# on the bureau's private model.
# ---------------------------------------------------------------------------
INQUIRY_HIT = 8            # a new loan application = hard enquiry + a brand-new account
MISSED_EMI_PENALTY = 80    # one 30-day-late payment typically costs ~60-110 points
ON_TIME_BONUS_PER_MONTH = 1.0
ON_TIME_BONUS_CAP = 20     # a fully repaid loan, paid on time, builds credit history

SCORE_MIN, SCORE_MAX = 300, 900


def _clamp(score: float) -> int:
    return int(max(SCORE_MIN, min(SCORE_MAX, round(score))))


def score_band(score: int) -> str:
    if score >= 750:
        return "Excellent"
    if score >= 700:
        return "Good"
    if score >= 650:
        return "Fair"
    return "Needs work"


def dti_penalty(dti_pct: float) -> int:
    """Points lost for carrying a heavy monthly-debt load relative to income."""
    if dti_pct <= 20:
        return 0
    if dti_pct <= 35:
        return 10
    if dti_pct <= 50:
        return 25
    return 45


class CreditImpactEstimator:
    @staticmethod
    def estimate(
        current_score: int,
        monthly_income: float,
        existing_debt_emi: float,
        new_emi: float = 0.0,
        tenure_months: int = 0,
    ) -> Dict[str, Any]:
        """
        Projects how a new EMI could move the user's credit score.

        - No new EMI (cash purchase / not buying): no borrowing, so no impact.
        - New EMI: a small up-front dip (enquiry + new account), an extra penalty
          while the debt-to-income ratio is high, a slow climb as on-time payments
          build history, and a clear warning figure for one missed EMI.
        """
        current_score = _clamp(current_score)

        dti_before = (existing_debt_emi / monthly_income * 100.0) if monthly_income > 0 else 0.0
        dti_after = ((existing_debt_emi + new_emi) / monthly_income * 100.0) if monthly_income > 0 else 0.0

        if new_emi <= 0:
            return {
                "has_new_loan": False,
                "current_score": current_score,
                "score_at_purchase": current_score,
                "score_after_loan": current_score,
                "score_if_emi_missed": current_score,
                "dti_before_pct": round_curr(dti_before),
                "dti_after_pct": round_curr(dti_before),
                "band_now": score_band(current_score),
                "band_at_purchase": score_band(current_score),
                "headline": "No credit impact. You are not taking on new borrowing.",
            }

        penalty = dti_penalty(dti_after)
        at_purchase = _clamp(current_score - INQUIRY_HIT - penalty)
        bonus = min(ON_TIME_BONUS_CAP, tenure_months * ON_TIME_BONUS_PER_MONTH)
        after_loan = _clamp(current_score + bonus)
        if_missed = _clamp(at_purchase - MISSED_EMI_PENALTY)

        dip = current_score - at_purchase
        if dip <= 0:
            headline = "Minimal credit impact."
        else:
            headline = (
                f"Expect a dip of about {dip} points at the start, "
                f"recovering to roughly {after_loan} if every EMI is paid on time."
            )

        return {
            "has_new_loan": True,
            "current_score": current_score,
            "score_at_purchase": at_purchase,
            "score_after_loan": after_loan,
            "score_if_emi_missed": if_missed,
            "dti_before_pct": round_curr(dti_before),
            "dti_after_pct": round_curr(dti_after),
            "band_now": score_band(current_score),
            "band_at_purchase": score_band(at_purchase),
            "headline": headline,
        }
