"""
Live counters, "online now" tracking, the community activity feed and personal streaks.

Privacy: the public numbers and feed are aggregates and never contain names, emails or
exact figures that identify anyone (amounts are rounded to a range).
"""
from __future__ import annotations

from datetime import date, datetime, timedelta
from typing import Dict, List, Optional, Tuple

from sqlalchemy import func
from sqlalchemy.orm import Session

from ..models import ActivityEvent, Heartbeat, User

ONLINE_WINDOW = timedelta(seconds=90)
FEED_TEXT = {
    "signup": "🎉 A new person joined",
    "guest": "👀 Someone is trying the demo",
    "purchase_check": "🛍️ Someone checked if they can afford a purchase",
    "simulation": "🔮 Someone stress-tested their savings",
    "emi_paid": "✅ Someone marked an EMI as paid",
}


def record(db: Session, kind: str, user_id: Optional[int] = None, amount: Optional[float] = None) -> None:
    db.add(ActivityEvent(user_id=user_id, kind=kind, amount=amount))
    db.commit()


def heartbeat(db: Session, session_id: str, user_id: Optional[int]) -> None:
    row = db.query(Heartbeat).filter(Heartbeat.session_id == session_id).first()
    now = datetime.utcnow()
    if row:
        row.last_seen, row.user_id = now, user_id
    else:
        db.add(Heartbeat(session_id=session_id, user_id=user_id, last_seen=now))
    db.commit()


def online_now(db: Session) -> int:
    return db.query(Heartbeat).filter(Heartbeat.last_seen >= datetime.utcnow() - ONLINE_WINDOW).count()


def ago(then: datetime, now: Optional[datetime] = None) -> str:
    secs = max(0, int(((now or datetime.utcnow()) - then).total_seconds()))
    if secs < 10:
        return "just now"
    if secs < 60:
        return f"{secs}s ago"
    if secs < 3600:
        return f"{secs // 60}m ago"
    if secs < 86400:
        return f"{secs // 3600}h ago"
    return f"{secs // 86400}d ago"


def live_stats(db: Session, feed_size: int = 6) -> Dict:
    def count(kind: str) -> int:
        return db.query(func.count(ActivityEvent.id)).filter(ActivityEvent.kind == kind).scalar() or 0

    analysed = db.query(func.coalesce(func.sum(ActivityEvent.amount), 0.0)).filter(
        ActivityEvent.kind == "purchase_check").scalar() or 0.0
    members = db.query(func.count(User.id)).filter(User.is_guest.is_(False)).scalar() or 0
    now = datetime.utcnow()
    feed: List[Dict] = []
    rows = (db.query(ActivityEvent).filter(ActivityEvent.kind.in_(list(FEED_TEXT)))
            .order_by(ActivityEvent.id.desc()).limit(feed_size).all())
    for r in rows:
        feed.append({"text": FEED_TEXT[r.kind], "when": ago(r.created_at, now)})
    return {
        "visits": count("visit"),
        "members": members,
        "online": online_now(db),
        "simulations": count("simulation") + count("purchase_check"),
        "analysed_amount": float(analysed),
        "feed": feed,
    }


# ------------------------------------------------------------------ streaks
def record_daily_visit(db: Session, user_id: int, today: date) -> bool:
    """One 'daily' event per user per calendar day. Returns True if this is the day's first."""
    start = datetime(today.year, today.month, today.day)
    exists = db.query(ActivityEvent.id).filter(
        ActivityEvent.user_id == user_id, ActivityEvent.kind == "daily",
        ActivityEvent.created_at >= start, ActivityEvent.created_at < start + timedelta(days=1)).first()
    if exists:
        return False
    db.add(ActivityEvent(user_id=user_id, kind="daily", created_at=start + timedelta(hours=12)))
    db.commit()
    return True


def streak(db: Session, user_id: int, today: date) -> Tuple[int, int, int]:
    """(current streak in days, best streak, total days used). A streak survives until the end of the next day."""
    rows = db.query(ActivityEvent.created_at).filter(
        ActivityEvent.user_id == user_id, ActivityEvent.kind == "daily").all()
    days = sorted({r[0].date() for r in rows})
    if not days:
        return 0, 0, 0
    best = run = 1
    for a, b in zip(days, days[1:]):
        run = run + 1 if (b - a).days == 1 else 1
        best = max(best, run)
    current = 0
    if (today - days[-1]).days <= 1:        # used today or yesterday: still alive
        current = 1
        for a, b in zip(reversed(days[:-1]), reversed(days)):
            if (b - a).days == 1:
                current += 1
            else:
                break
    return current, best, len(days)
