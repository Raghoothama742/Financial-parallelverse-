from datetime import date
from html.parser import HTMLParser

import pytest

from frontend_streamlit import pv_ui, pv_theme


# ------------------------------------------------------------------ number formatting
@pytest.mark.parametrize("value,expected", [
    (0, "₹0"), (999, "₹999"), (1000, "₹1,000"), (70000, "₹70,000"),
    (120000, "₹1,20,000"), (1234567, "₹12,34,567"), (12345678, "₹1,23,45,678"),
    (-4500, "-₹4,500"), (None, "₹0"), (float("nan"), "₹0"), (-0.2, "₹0"),
])
def test_inr_uses_indian_grouping(value, expected):
    assert pv_ui.inr(value) == expected


def test_inr_decimals():
    assert pv_ui.inr(-4500.5, 2) == "-₹4,500.50"
    assert pv_ui.inr(1234567.891, 2) == "₹12,34,567.89"


@pytest.mark.parametrize("m,expected", [
    (3.0, "3 months"), (1.0, "1 month"), (1.5, "1.5 months"), (0.0, "0 months"),
    (10.0, "10 months"), (99.0, "8+ years"),
])
def test_months_text(m, expected):
    assert pv_ui.months_text(m) == expected


@pytest.mark.parametrize("hour,expected", [
    (0, "Hey night owl"), (4, "Hey night owl"), (5, "Good morning"), (11, "Good morning"),
    (12, "Good afternoon"), (16, "Good afternoon"), (17, "Good evening"), (20, "Good evening"),
    (21, "Hey night owl"), (23, "Hey night owl"),
])
def test_greeting(hour, expected):
    assert pv_ui.greeting(hour) == expected


def test_days_label():
    today = date(2026, 10, 24)
    assert pv_ui.days_label(date(2026, 10, 24), today) == "due today"
    assert pv_ui.days_label(date(2026, 10, 25), today) == "due tomorrow"
    assert pv_ui.days_label(date(2026, 10, 29), today) == "due in 5 days"
    assert pv_ui.days_label(date(2026, 10, 23), today) == "1 day late"
    assert pv_ui.days_label(date(2026, 10, 20), today) == "4 days late"


def test_score_tone_bands():
    assert [pv_ui.score_tone(s) for s in (100, 80, 79, 60, 59, 40, 39, 0)] == \
        ["good", "good", "info", "info", "warn", "warn", "bad", "bad"]


def test_biggest_boost_picks_largest_gap():
    breakdown = {
        "saving_habit": {"points": 30, "max": 30},
        "safety_net": {"points": 10, "max": 30},      # gap 20  <- biggest
        "debt_load": {"points": 20, "max": 25},
        "emergency_fund": {"points": 12, "max": 15},
    }
    assert pv_ui.biggest_boost(breakdown) == ("Grow your safety net", 20)


def test_verdict_for_every_option():
    assert pv_ui.verdict_for("buy_cash_now")[0] == "good"
    assert pv_ui.verdict_for("buy_via_emi")[0] == "info"
    assert pv_ui.verdict_for("cheaper_alternative")[0] == "info"
    tone, _, headline = pv_ui.verdict_for("save_and_wait", 6)
    assert tone == "warn" and "6 months" in headline   # waiting is prudent advice, not an alarm


# ------------------------------------------------------------------ HTML safety
class _Balance(HTMLParser):
    VOID = {"br", "img", "hr", "input", "meta", "link"}

    def __init__(self):
        super().__init__()
        self.stack, self.errors = [], []

    def handle_starttag(self, tag, attrs):
        if tag not in self.VOID:
            self.stack.append(tag)

    def handle_endtag(self, tag):
        if not self.stack or self.stack[-1] != tag:
            self.errors.append(f"unexpected </{tag}> (open: {self.stack[-3:]})")
        else:
            self.stack.pop()


def assert_balanced(html: str):
    p = _Balance()
    p.feed(html)
    p.close()
    assert not p.errors, p.errors
    assert not p.stack, f"unclosed tags: {p.stack}"


SAMPLE_OPTION = {
    "option_id": "buy_via_emi", "option_title": "x", "upfront_cash_required": 10000.0,
    "monthly_obligation": 5400.0, "total_cost": 74800.0, "remaining_savings_immediately": 110000.0,
    "emergency_buffer_preserved_pct": 73.0, "safe_to_proceed": True, "risk_rating": "CAUTION",
    "key_tradeoff": "Low upfront cash, paid for by future cash flow.",
}
SAMPLE_FUTURE = {
    "scenario_name": "x", "risk_level": "HIGH", "lowest_savings": -12500.0, "resilience_score": 41,
    "negative_cash_months": 2, "breaking_point_reason": "Savings depleted in Month 4.",
}


def test_all_blocks_are_well_formed():
    blocks = [
        pv_ui.section("Title", "sub"), pv_ui.section("Only title"),
        pv_ui.pill("Safe", "good"),
        pv_ui.stat("Left over", "₹20,000", "27% saved", "good", "💵", unit="/mo"),
        pv_ui.banner("warn", "⚠️", "Careful", "Body text"),
        pv_ui.meter(3, 6, "good"),
        pv_ui.ring(82, "Strong", "good"),
        pv_ui.split_bar([("Essentials", 32000, "info"), ("Fun", 15000, "brand"), ("EMIs", 8000, "warn"), ("Left", 20000, "good")]),
        pv_ui.option_card(SAMPLE_OPTION, True), pv_ui.option_card(SAMPLE_OPTION, False),
        pv_ui.future_card("combined_adverse", SAMPLE_FUTURE),
        pv_ui.data_table(["Month", "Balance"], [["1", "₹1,000"], ["2", "₹2,000"]]),
        pv_ui.grid([pv_ui.pill("a"), pv_ui.pill("b")], 2),
    ]
    for b in blocks:
        assert_balanced(b)


def test_user_text_is_escaped():
    evil = '<img src=x onerror=alert(1)>'
    for out in (
        pv_ui.section(evil, evil), pv_ui.pill(evil), pv_ui.stat(evil, evil, evil, "good", evil),
        pv_ui.banner("good", evil, evil, evil),
        pv_ui.split_bar([(evil, 100, "good")]),
        pv_ui.data_table([evil], [[evil]]),
    ):
        assert "<img" not in out
        assert "&lt;img" in out


def test_split_bar_handles_zero_and_negative_totals():
    assert "Add your income" in pv_ui.split_bar([("a", 0, "good"), ("b", -5, "bad")])


def test_split_bar_widths_sum_to_100():
    html = pv_ui.split_bar([("a", 1, "good"), ("b", 3, "info")])
    import re
    widths = [float(w) for w in re.findall(r'style="width:([\d.]+)%"', html)]
    assert sum(widths) == pytest.approx(100.0, abs=0.01)


def test_ring_clamps_score():
    assert "--p:100" in pv_ui.ring(250, "x", "good")
    assert "--p:0" in pv_ui.ring(-10, "x", "bad")


def test_no_svg_anywhere_because_streamlit_strips_it():
    # Found by screenshotting the real app: st.html's sanitiser removes <svg>, leaving a blank hole.
    sample = [
        pv_ui.ring(80, "Strong", "good"), pv_ui.stat("a", "b"), pv_ui.banner("good", "x", "y"),
        pv_ui.option_card(SAMPLE_OPTION, True), pv_ui.future_card("baseline", SAMPLE_FUTURE),
        pv_ui.split_bar([("a", 1, "good")]), pv_ui.meter(1, 2),
    ]
    assert not any("<svg" in h.lower() for h in sample)


def test_future_card_flags_negative_balance():
    assert "pv-c-bad" in pv_ui.future_card("baseline", SAMPLE_FUTURE)
    ok = dict(SAMPLE_FUTURE, lowest_savings=50000.0, negative_cash_months=0)
    assert pv_ui.future_card("baseline", ok).count("pv-c-bad") == 0


def test_future_card_never_calls_a_negative_balance_fine():
    # Engine can score a future "MODERATE" even though cash goes below zero (real case: -₹672).
    sneaky = dict(SAMPLE_FUTURE, risk_level="MODERATE", lowest_savings=-672.0, negative_cash_months=1)
    html = pv_ui.future_card("combined_adverse", sneaky)
    assert ">Risky<" in html and ">Okay<" not in html
    clean = dict(SAMPLE_FUTURE, risk_level="MODERATE", lowest_savings=50000.0, negative_cash_months=0)
    assert ">Okay<" in pv_ui.future_card("baseline", clean)
    critical = dict(SAMPLE_FUTURE, risk_level="CRITICAL")
    assert ">Danger<" in pv_ui.future_card("baseline", critical)


def test_every_engine_scenario_has_plain_english_copy():
    from backend.app.services.scenario_engine import ScenarioEngine
    res = ScenarioEngine.simulate_all_scenarios(
        duration_months=6, monthly_income=70000, current_savings=100000, essential_expenses=30000,
        discretionary_expenses=10000, existing_debt_emi=5000, emergency_fund_target=80000, purchase_mode="NONE")
    assert set(res["scenarios"]) == set(pv_ui.FUTURES) == set(pv_ui.FUTURE_COLORS)


# ------------------------------------------------------------------ readability (WCAG)
def _lin(c):
    c /= 255
    return c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4


def _rgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def _lum(h):
    r, g, b = _rgb(h)
    return 0.2126 * _lin(r) + 0.7152 * _lin(g) + 0.0722 * _lin(b)


def _contrast(a, b):
    hi, lo = max(_lum(a), _lum(b)), min(_lum(a), _lum(b))
    return (hi + 0.05) / (lo + 0.05)


def _mix(fg, bg, share):
    f, b = _rgb(fg), _rgb(bg)
    return "#%02x%02x%02x" % tuple(round(f[i] * share + b[i] * (1 - share)) for i in range(3))


@pytest.mark.parametrize("name,palette,page_bg", [
    ("light", pv_theme.LIGHT, "#FFFFFF"),
    ("dark", pv_theme.DARK, "#0E1117"),     # Streamlit's default light/dark page backgrounds
])
def test_palette_is_readable(name, palette, page_bg):
    surface = palette["surface"]
    assert _contrast(palette["text"], surface) >= 7
    assert _contrast(palette["muted"], surface) >= 4.5
    for tone in ("good", "warn", "bad", "info", "brand"):
        colour = palette[tone]
        assert _contrast(colour, surface) >= 4.5, f"{name} {tone} on surface"
        tint = _mix(colour, surface, 0.12)       # pill + banner background
        assert _contrast(colour, tint) >= 4.5, f"{name} {tone} pill text"
        assert _contrast(palette["text"], tint) >= 7, f"{name} banner text on {tone}"
    # gradient page title is large text (needs 3:1) and sits on the bare page
    assert _contrast(palette["grad_a"], page_bg) >= 3
    assert _contrast(palette["grad_b"], page_bg) >= 3


def test_every_css_variable_used_is_defined():
    import re
    css = pv_theme.get_css()
    used = set(re.findall(r"var\(--(pv-[a-z0-9-]+)\)", css))
    defined = set(re.findall(r"--(pv-[a-z0-9-]+):", css))
    # --pv-c / --pv-to are set inline by the ring; --pv-future by each future card
    assert used - defined <= {"pv-future"}, used - defined - {"pv-future"}


def test_css_braces_are_balanced():
    css = pv_theme.get_css()
    assert css.count("{") == css.count("}")


def test_no_block_ever_returns_empty_html():
    # st.html("") raises StreamlitMissingRequiredParameterError and would crash the page.
    assert pv_ui.strength_bar(0, "").strip() != ""
    assert pv_ui.strength_bar(3, "Strong").strip() != ""
    assert pv_ui.live_panel({"online": 0, "visits": 0, "members": 0, "analysed_amount": 0.0, "feed": []}).strip() != ""
    assert pv_ui.streak_chip(0).strip() != "" and pv_ui.streak_chip(5).strip() != ""


def test_live_panel_shows_numbers_and_escapes_feed():
    html = pv_ui.live_panel({"online": 3, "visits": 12345, "members": 7, "analysed_amount": 2_50_00_000.0,
                             "feed": [{"text": "<script>x</script>", "when": "2m ago"}]})
    assert "12,345" in html and ">3<" in html and "₹2.5 Cr" in html
    assert "<script>" not in html and "&lt;script&gt;" in html
    assert_balanced(html)


@pytest.mark.parametrize("v,expected", [(0, "₹0"), (99999, "₹99,999"), (100000, "₹1.0 L"), (450000, "₹4.5 L"), (12_000_000, "₹1.2 Cr")])
def test_compact_inr(v, expected):
    assert pv_ui.compact_inr(v) == expected
