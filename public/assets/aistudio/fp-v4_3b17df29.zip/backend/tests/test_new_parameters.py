import pytest
from sqlalchemy import create_engine, text
from backend.app.database import migrate_schema
from backend.app.services.scenario_engine import ScenarioEngine
from backend.app.services.financial_engine import FinancialEngine
from backend.app.services.credit_impact import CreditImpactEstimator


def _sim(**overrides):
    """A flat, easy-to-reason-about household: income exactly covers expenses (net 0/month)."""
    args = dict(
        duration_months=12,
        monthly_income=50000.0,
        current_savings=200000.0,
        essential_expenses=40000.0,
        discretionary_expenses=10000.0,
        existing_debt_emi=0.0,
        emergency_fund_target=100000.0,
        purchase_mode="NONE",
    )
    args.update(overrides)
    return ScenarioEngine.simulate_all_scenarios(**args)


# ---------------------------------------------------------------- 1. income growth
def test_income_growth_steps_up_each_year():
    res = _sim(duration_months=24, monthly_income=100000.0, income_growth_pct=10.0)
    tl = res["scenarios"]["baseline"]["timeline"]
    assert tl[11]["income_received"] == 100000.0   # month 12: still year one
    assert tl[12]["income_received"] == 110000.0   # month 13: 10% raise kicks in


def test_zero_growth_keeps_income_flat():
    tl = _sim(duration_months=24)["scenarios"]["baseline"]["timeline"]
    assert {t["income_received"] for t in tl} == {50000.0}


def test_delayed_salary_catch_up_uses_that_months_income():
    res = _sim(duration_months=24, income_growth_pct=10.0,
               salary_delay_start_month=13, salary_delay_months=1)
    tl = res["scenarios"]["delayed_salary"]["timeline"]
    assert tl[12]["income_received"] == 0.0        # month 13 delayed
    assert tl[13]["income_received"] == 55000.0 + 55000.0   # month 14 = grown pay + the delayed month


# ---------------------------------------------------------------- 2. investment return
def test_investment_return_compounds_monthly():
    # 12%/yr = 1%/month. Net cash flow is 0, so only interest moves the balance.
    res = _sim(current_savings=100000.0, investment_return_pct=12.0)
    tl = res["scenarios"]["baseline"]["timeline"]
    assert tl[0]["interest_earned"] == 1000.0
    assert tl[0]["closing_savings"] == 101000.0
    assert tl[1]["interest_earned"] == 1010.0
    assert tl[1]["closing_savings"] == 102010.0
    # 100000 * (1.01^12 - 1) = 12682.50
    assert res["scenarios"]["baseline"]["total_interest_earned"] == pytest.approx(12682.50, abs=0.5)


def test_no_interest_earned_on_a_deficit_balance():
    res = _sim(current_savings=0.0, monthly_income=30000.0, investment_return_pct=12.0)
    tl = res["scenarios"]["baseline"]["timeline"]
    assert tl[1]["opening_savings"] < 0
    assert tl[1]["interest_earned"] == 0.0


def test_zero_return_matches_original_behaviour():
    tl = _sim()["scenarios"]["baseline"]["timeline"]
    assert all(t["interest_earned"] == 0.0 for t in tl)
    assert tl[-1]["closing_savings"] == 200000.0


# ---------------------------------------------------------------- 3. job-loss runway
def test_job_loss_runway_basic():
    # 120k savings, 30k essentials + 10k EMI = 40k/month -> exactly 3 months
    assert FinancialEngine.job_loss_runway(120000, 30000, 10000) == 3.0


def test_job_loss_runway_after_cash_purchase():
    # buying 60k cash leaves 60k -> 1.5 months
    assert FinancialEngine.job_loss_runway(120000, 30000, 10000, upfront_purchase_cost=60000) == 1.5


def test_job_loss_runway_after_emi_purchase():
    # 20k down leaves 100k; monthly need becomes 40k + 10k new EMI = 50k -> 2 months
    got = FinancialEngine.job_loss_runway(
        120000, 30000, 10000, upfront_purchase_cost=20000, new_emi=10000, new_emi_months=12)
    assert got == 2.0


def test_job_loss_runway_is_zero_when_purchase_exceeds_savings():
    assert FinancialEngine.job_loss_runway(50000, 30000, 0, upfront_purchase_cost=60000) == 0.0


def test_job_loss_runway_grows_with_investment_return():
    assert FinancialEngine.job_loss_runway(120000, 30000, 10000, investment_return_pct=12.0) > 3.0


def test_engine_reports_runway_before_and_after():
    res = _sim(current_savings=120000.0, essential_expenses=30000.0, existing_debt_emi=10000.0,
               monthly_income=60000.0, discretionary_expenses=10000.0,
               purchase_mode="CASH", purchase_amount=60000.0)
    s = res["comparison_summary"]
    assert s["job_loss_runway_before_months"] == 3.0
    assert s["job_loss_runway_after_months"] == 1.5


# ---------------------------------------------------------------- 4. credit impact
def test_credit_emi_causes_dip_then_recovery():
    r = CreditImpactEstimator.estimate(
        current_score=750, monthly_income=75000, existing_debt_emi=8000, new_emi=6000, tenure_months=12)
    assert r["has_new_loan"] is True
    assert r["dti_after_pct"] == pytest.approx(18.67, abs=0.01)
    assert r["score_at_purchase"] == 742          # 750 - 8 enquiry, DTI under 20% so no extra penalty
    assert r["score_after_loan"] == 762           # +12 for 12 on-time months
    assert r["score_if_emi_missed"] == 662        # 742 - 80


def test_credit_high_dti_adds_penalty():
    r = CreditImpactEstimator.estimate(
        current_score=750, monthly_income=50000, existing_debt_emi=15000, new_emi=15000, tenure_months=12)
    assert r["dti_after_pct"] == 60.0
    assert r["score_at_purchase"] == 750 - 8 - 45


def test_credit_cash_purchase_has_no_impact():
    r = CreditImpactEstimator.estimate(
        current_score=720, monthly_income=75000, existing_debt_emi=8000, new_emi=0, tenure_months=0)
    assert r["has_new_loan"] is False
    assert r["score_at_purchase"] == r["score_after_loan"] == r["current_score"] == 720


def test_credit_score_never_leaves_300_900():
    low = CreditImpactEstimator.estimate(310, 20000, 9000, 9000, 12)
    assert low["score_if_emi_missed"] == 300
    high = CreditImpactEstimator.estimate(895, 100000, 0, 2000, 60)
    assert high["score_after_loan"] == 900


def test_engine_includes_credit_impact_only_for_emi():
    emi = _sim(purchase_mode="EMI", purchase_amount=60000.0, emi_down_payment=10000.0,
               credit_score=750)["comparison_summary"]["credit_impact"]
    cash = _sim(purchase_mode="CASH", purchase_amount=60000.0)["comparison_summary"]["credit_impact"]
    assert emi["has_new_loan"] is True and emi["score_at_purchase"] < 750
    assert cash["has_new_loan"] is False


# ---------------------------------------------------------------- 5. true / opportunity cost
def test_true_cost_equals_price_when_no_returns():
    s = _sim(purchase_mode="CASH", purchase_amount=60000.0)["comparison_summary"]
    assert s["cash_paid_in_horizon"] == 60000.0
    assert s["true_cost_of_purchase"] == 60000.0
    assert s["opportunity_cost"] == 0.0


def test_opportunity_cost_is_forgone_growth():
    s = _sim(purchase_mode="CASH", purchase_amount=60000.0,
             investment_return_pct=12.0)["comparison_summary"]
    # Paid in month 1; the 60k would have compounded at 1%/month for the remaining 11 months.
    expected_true_cost = 60000.0 * (1.01 ** 11)
    assert s["true_cost_of_purchase"] == pytest.approx(expected_true_cost, abs=1.0)
    assert s["opportunity_cost"] == pytest.approx(expected_true_cost - 60000.0, abs=1.0)
    assert s["opportunity_cost"] > 0


def test_not_buying_costs_nothing():
    s = _sim(purchase_mode="NONE", investment_return_pct=12.0)["comparison_summary"]
    assert s["true_cost_of_purchase"] == 0.0
    assert s["opportunity_cost"] == 0.0


# ---------------------------------------------------------------- health score
def test_health_score_strong_profile():
    m = FinancialEngine.calculate_profile_metrics(75000, 120000, 32000, 15000, 8000, 150000)
    assert m["health_score"] == 82
    assert m["health_label"] == "Strong"


def test_health_score_stressed_profile():
    m = FinancialEngine.calculate_profile_metrics(30000, 5000, 25000, 10000, 10000, 100000)
    assert m["health_score"] < 40
    assert m["health_label"] == "Needs care"


def test_health_breakdown_adds_up():
    m = FinancialEngine.calculate_profile_metrics(75000, 120000, 32000, 15000, 8000, 150000)
    total = sum(p["points"] for p in m["health_breakdown"].values())
    assert round(total) == m["health_score"]


# ---------------------------------------------------------------- API + migration
def test_simulate_api_returns_new_insights(client):
    res = client.post("/api/scenarios/simulate", json={
        "duration_months": 12, "monthly_income": 80000.0, "current_savings": 150000.0,
        "essential_expenses": 30000.0, "discretionary_expenses": 15000.0,
        "existing_debt_emi": 5000.0, "emergency_fund_target": 120000.0,
        "purchase_mode": "EMI", "purchase_amount": 70000.0,
        "income_growth_pct": 8.0, "investment_return_pct": 7.0, "credit_score": 710,
    })
    assert res.status_code == 200
    body = res.json()
    s = body["comparison_summary"]
    for key in ("true_cost_of_purchase", "opportunity_cost", "job_loss_runway_before_months",
                "job_loss_runway_after_months", "credit_impact", "dti_after_purchase_pct"):
        assert key in s
    assert s["credit_impact"]["current_score"] == 710
    month1 = body["scenarios"]["baseline"]["timeline"][0]
    assert month1["interest_earned"] > 0


def test_profile_saves_new_fields_and_old_clients_do_not_reset_them(client):
    base = {
        "full_name": "Param Test", "monthly_income": 80000.0, "current_savings": 150000.0,
        "essential_expenses": 30000.0, "discretionary_expenses": 10000.0, "existing_debt_emi": 5000.0,
        "emergency_fund_target": 150000.0, "planned_purchase_name": "Phone",
        "planned_purchase_amount": 40000.0, "planned_purchase_month": 1,
    }
    put = client.put("/api/profile", json={**base, "income_growth_pct": 8.5,
                                           "investment_return_pct": 9.0, "credit_score": 780})
    assert put.status_code == 200
    got = put.json()
    assert (got["income_growth_pct"], got["investment_return_pct"], got["credit_score"]) == (8.5, 9.0, 780)
    assert "health_score" in got and got["health_label"]

    # An older client that never sends the new fields must not wipe them.
    put2 = client.put("/api/profile", json={**base, "monthly_income": 85000.0})
    assert put2.status_code == 200
    again = client.get("/api/profile").json()
    assert again["monthly_income"] == 85000.0
    assert (again["income_growth_pct"], again["investment_return_pct"], again["credit_score"]) == (8.5, 9.0, 780)


def test_migration_adds_missing_columns_to_an_old_database(tmp_path):
    old = create_engine(f"sqlite:///{tmp_path / 'old.db'}")
    with old.begin() as c:
        c.execute(text("CREATE TABLE financial_profiles (id INTEGER PRIMARY KEY, full_name VARCHAR(100), "
                       "monthly_income FLOAT NOT NULL)"))
        c.execute(text("INSERT INTO financial_profiles (id, full_name, monthly_income) VALUES (1, 'Old User', 60000)"))

    added = migrate_schema(old)
    assert {"financial_profiles.credit_score", "financial_profiles.income_growth_pct",
            "financial_profiles.investment_return_pct", "financial_profiles.user_id",
            "financial_profiles.onboarded"} <= set(added)
    with old.connect() as c:
        row = c.execute(text("SELECT monthly_income, income_growth_pct, investment_return_pct, credit_score, onboarded, user_id "
                             "FROM financial_profiles")).one()
    assert tuple(row) == (60000.0, 5.0, 6.0, 750, 1, None)   # data kept; legacy row has no owner yet
    assert migrate_schema(old) == []                    # running again is a no-op
