import uuid
from datetime import datetime, timedelta

import pytest

from backend.app.models import ActivityEvent, AuthSession, FinancialProfile, Heartbeat, InstallmentPlan, User
from backend.app.services import activity, auth_service
from backend.app.services.auth_service import AuthError

PW = "correct-horse-battery"


def _email():
    return f"{uuid.uuid4().hex[:10]}@example.com"


# ------------------------------------------------------------------ passwords
def test_hash_is_salted_and_verifies():
    a, b = auth_service.hash_password(PW), auth_service.hash_password(PW)
    assert a != b                                   # random salt
    assert PW not in a and a.startswith("scrypt$")
    assert auth_service.verify_password(PW, a)
    assert not auth_service.verify_password(PW + "x", a)


@pytest.mark.parametrize("stored", [None, "", "garbage", "scrypt$1$2", "md5$a$b$c$d$e"])
def test_verify_never_crashes_on_bad_hashes(stored):
    assert auth_service.verify_password(PW, stored) is False


@pytest.mark.parametrize("pw", ["short", "", "password", "12345678", "x" * 201])
def test_weak_passwords_rejected(pw):
    with pytest.raises(AuthError):
        auth_service.validate_password(pw)


@pytest.mark.parametrize("email", ["", "nope", "a@b", "a@@b.com", "a b@c.com", "x" * 260 + "@a.com"])
def test_bad_emails_rejected(email):
    with pytest.raises(AuthError):
        auth_service.validate_email(email)


def test_strength_meter_orders_sensibly():
    scores = [auth_service.password_strength(p)[0] for p in ["", "abc", "abcdefgh", "Abcdefgh12", "Abcdefgh12!xyz"]]
    assert scores == sorted(scores) and scores[0] == 0 and scores[-1] == 4


# ------------------------------------------------------------------ register / login
def test_register_login_roundtrip(db_session):
    email = _email()
    u = auth_service.register(db_session, email.upper(), "  Asha  ", PW)
    assert u.email == email and u.name == "Asha" and u.password_hash != PW
    assert auth_service.authenticate(db_session, email, PW).id == u.id


def test_duplicate_email_rejected_case_insensitively(db_session):
    email = _email()
    auth_service.register(db_session, email, "A", PW)
    with pytest.raises(AuthError, match="already exists"):
        auth_service.register(db_session, email.upper(), "B", PW)


def test_wrong_password_and_unknown_email_look_identical(db_session):
    email = _email()
    auth_service.register(db_session, email, "A", PW)
    with pytest.raises(AuthError) as wrong:
        auth_service.authenticate(db_session, email, "nope-nope-nope")
    with pytest.raises(AuthError) as unknown:
        auth_service.authenticate(db_session, _email(), PW)
    assert str(wrong.value) == str(unknown.value) == auth_service.GENERIC_LOGIN_ERROR


def test_lockout_after_five_failures_then_expires(db_session):
    email = _email()
    u = auth_service.register(db_session, email, "A", PW)
    for _ in range(5):
        with pytest.raises(AuthError):
            auth_service.authenticate(db_session, email, "wrong-wrong")
    with pytest.raises(AuthError, match="Too many"):
        auth_service.authenticate(db_session, email, PW)          # even the right password is refused
    u.locked_until = datetime.utcnow() - timedelta(seconds=1)      # time passes
    db_session.commit()
    assert auth_service.authenticate(db_session, email, PW).id == u.id
    assert u.failed_attempts == 0


def test_success_resets_failure_counter(db_session):
    email = _email()
    u = auth_service.register(db_session, email, "A", PW)
    for _ in range(3):
        with pytest.raises(AuthError):
            auth_service.authenticate(db_session, email, "wrong-wrong")
    auth_service.authenticate(db_session, email, PW)
    assert u.failed_attempts == 0


# ------------------------------------------------------------------ sessions
def test_token_not_stored_in_clear_and_expires(db_session):
    u = auth_service.register(db_session, _email(), "A", PW)
    token = auth_service.create_session(db_session, u)
    assert db_session.query(AuthSession).filter(AuthSession.token_hash == token).count() == 0
    assert auth_service.user_from_token(db_session, token).id == u.id
    row = db_session.query(AuthSession).filter(AuthSession.user_id == u.id).one()
    row.expires_at = datetime.utcnow() - timedelta(seconds=1)
    db_session.commit()
    assert auth_service.user_from_token(db_session, token) is None
    assert db_session.query(AuthSession).filter(AuthSession.user_id == u.id).count() == 0   # cleaned up


def test_logout_revokes(db_session):
    u = auth_service.register(db_session, _email(), "A", PW)
    t = auth_service.create_session(db_session, u)
    auth_service.revoke_session(db_session, t)
    assert auth_service.user_from_token(db_session, t) is None


@pytest.mark.parametrize("token", [None, "", "abc", "x" * 500])
def test_garbage_tokens_are_rejected(db_session, token):
    assert auth_service.user_from_token(db_session, token) is None


def test_password_change_signs_out_everywhere(db_session):
    u = auth_service.register(db_session, _email(), "A", PW)
    t = auth_service.create_session(db_session, u)
    with pytest.raises(AuthError):
        auth_service.change_password(db_session, u, "wrong", "brand-new-password")
    auth_service.change_password(db_session, u, PW, "brand-new-password")
    assert auth_service.user_from_token(db_session, t) is None
    assert auth_service.authenticate(db_session, u.email, "brand-new-password").id == u.id


# ------------------------------------------------------------------ guests + cleanup
def test_guest_gets_prefilled_data_and_short_session(db_session):
    g = auth_service.create_guest(db_session)
    assert g.is_guest and g.email is None and g.password_hash is None
    assert db_session.query(FinancialProfile).filter(FinancialProfile.user_id == g.id).count() == 1
    auth_service.create_session(db_session, g)
    exp = db_session.query(AuthSession).filter(AuthSession.user_id == g.id).one().expires_at
    assert exp - datetime.utcnow() <= timedelta(hours=24, seconds=5)


def test_expired_guests_are_purged_with_their_data(db_session):
    g = auth_service.create_guest(db_session)
    g.created_at = datetime.utcnow() - timedelta(hours=25)
    db_session.commit()
    gid = g.id
    auth_service.purge_expired(db_session)
    assert db_session.query(User).filter(User.id == gid).count() == 0
    assert db_session.query(FinancialProfile).filter(FinancialProfile.user_id == gid).count() == 0


def test_delete_account_removes_everything_but_keeps_anonymous_counts(db_session):
    u = auth_service.register(db_session, _email(), "A", PW)
    auth_service.get_or_create_profile(db_session, u)
    activity.record(db_session, "simulation", u.id)
    uid = u.id
    auth_service.delete_account(db_session, u)
    assert db_session.query(User).filter(User.id == uid).count() == 0
    assert db_session.query(FinancialProfile).filter(FinancialProfile.user_id == uid).count() == 0
    assert db_session.query(ActivityEvent).filter(ActivityEvent.user_id == uid).count() == 0


# ------------------------------------------------------------------ API + isolation
def test_api_requires_sign_in(anon_client):
    for method, url in [("get", "/api/profile"), ("get", "/api/installments"), ("post", "/api/purchases/evaluate"),
                        ("post", "/api/scenarios/simulate"), ("get", "/api/auth/me")]:
        r = getattr(anon_client, method)(url, **({"json": {}} if method == "post" else {}))
        assert r.status_code == 401, (method, url, r.status_code)
    bad = anon_client.get("/api/profile", headers={"Authorization": "Bearer not-a-real-token"})
    assert bad.status_code == 401


def test_api_register_login_me_logout_flow(anon_client):
    email = _email()
    r = anon_client.post("/api/auth/register", json={"email": email, "name": "Zed", "password": PW})
    assert r.status_code == 200 and "token" in r.json()
    assert "password" not in r.text
    r2 = anon_client.post("/api/auth/login", json={"email": email, "password": PW})
    token = r2.json()["token"]
    h = {"Authorization": f"Bearer {token}"}
    assert anon_client.get("/api/auth/me", headers=h).json()["name"] == "Zed"
    assert anon_client.post("/api/auth/login", json={"email": email, "password": "wrong-wrong"}).status_code == 401
    anon_client.post("/api/auth/logout", headers=h)
    assert anon_client.get("/api/auth/me", headers=h).status_code == 401
    assert anon_client.post("/api/auth/register", json={"email": "bad", "password": PW}).status_code == 400


def test_users_cannot_see_or_touch_each_others_data(client, anon_client, db_session):
    mine = client.post("/api/installments", json={
        "purchase_name": "My phone", "total_amount": 30000, "down_payment": 0,
        "annual_interest_rate": 10, "tenure_months": 6, "due_day": 5}).json()
    client.put("/api/profile", json={
        "full_name": "Me", "monthly_income": 111111.0, "current_savings": 1.0, "essential_expenses": 1.0,
        "discretionary_expenses": 1.0, "existing_debt_emi": 0.0, "emergency_fund_target": 1.0,
        "planned_purchase_name": "x", "planned_purchase_amount": 1.0, "planned_purchase_month": 1})

    other = auth_service.register(db_session, _email(), "Other", PW)
    h = {"Authorization": f"Bearer {auth_service.create_session(db_session, other)}"}

    assert anon_client.get("/api/installments", headers=h).json() == []                       # list is empty
    assert anon_client.get(f"/api/installments/{mine['id']}", headers=h).status_code == 404    # read blocked
    assert anon_client.delete(f"/api/installments/{mine['id']}", headers=h).status_code == 404 # delete blocked
    pay_id = mine["payments"][0]["id"]
    assert anon_client.patch(f"/api/installments/{mine['id']}/payments/{pay_id}", headers=h,
                             json={"status": "PAID"}).status_code == 404                      # mark-paid blocked
    assert anon_client.get(f"/api/installments/{mine['id']}/calendar", headers=h).status_code == 404
    assert anon_client.get("/api/profile", headers=h).json()["monthly_income"] != 111111.0     # own profile only
    assert client.get(f"/api/installments/{mine['id']}").status_code == 200                    # owner unaffected


def test_first_real_user_inherits_legacy_rows_and_later_users_do_not(db_session):
    db_session.query(InstallmentPlan).update({"user_id": 0})            # park existing rows out of the way
    db_session.add(FinancialProfile(user_id=None, full_name="legacy"))
    db_session.commit()
    existing_real = db_session.query(User).filter(User.is_guest.is_(False)).count()
    u = auth_service.register(db_session, _email(), "New", PW)
    legacy_owner = db_session.query(FinancialProfile).filter(FinancialProfile.full_name == "legacy").one().user_id
    if existing_real == 0:
        assert legacy_owner == u.id
    else:
        assert legacy_owner is None            # only the very first real account may claim old data


# ------------------------------------------------------------------ live tracker
def test_counters_online_now_and_feed(db_session):
    base = activity.live_stats(db_session)
    activity.record(db_session, "visit")
    activity.record(db_session, "purchase_check", None, 50000.0)
    activity.heartbeat(db_session, "tab-a", None)
    activity.heartbeat(db_session, "tab-a", None)          # same tab twice = still one
    activity.heartbeat(db_session, "tab-b", None)
    s = activity.live_stats(db_session)
    assert s["visits"] == base["visits"] + 1
    assert s["analysed_amount"] == base["analysed_amount"] + 50000.0
    assert s["online"] == base["online"] + 2
    assert s["feed"][0]["text"].startswith("🛍️") and "₹" not in s["feed"][0]["text"]
    row = db_session.query(Heartbeat).filter(Heartbeat.session_id == "tab-b").one()
    row.last_seen = datetime.utcnow() - timedelta(minutes=5)
    db_session.commit()
    assert activity.live_stats(db_session)["online"] == base["online"] + 1      # stale tab drops off


def test_public_feed_never_leaks_identity(db_session):
    u = auth_service.register(db_session, "secret.person@example.com", "Secret Person", PW)
    activity.record(db_session, "simulation", u.id)
    blob = str(activity.live_stats(db_session))
    assert "secret" not in blob.lower() and "example.com" not in blob


def test_live_stats_endpoint_is_public(anon_client):
    r = anon_client.get("/api/auth/stats/live")
    assert r.status_code == 200 and {"visits", "members", "online", "simulations", "feed"} <= set(r.json())


def test_api_actions_feed_the_counters(client, db_session):
    before = activity.live_stats(db_session)["simulations"]
    client.post("/api/purchases/evaluate", json={})
    client.post("/api/scenarios/simulate", json={"purchase_mode": "NONE"})
    assert activity.live_stats(db_session)["simulations"] == before + 2


# ------------------------------------------------------------------ streaks
def test_streak_math(db_session):
    from datetime import date
    u = auth_service.register(db_session, _email(), "S", PW)
    today = date(2026, 10, 25)
    assert activity.streak(db_session, u.id, today) == (0, 0, 0)
    for d in (date(2026, 10, 20), date(2026, 10, 21), date(2026, 10, 22),      # best run of 3
              date(2026, 10, 24), date(2026, 10, 25)):                          # current run of 2
        assert activity.record_daily_visit(db_session, u.id, d) is True
    assert activity.record_daily_visit(db_session, u.id, today) is False        # once per day
    assert activity.streak(db_session, u.id, today) == (2, 3, 5)
    assert activity.streak(db_session, u.id, date(2026, 10, 26))[0] == 2         # yesterday still counts
    assert activity.streak(db_session, u.id, date(2026, 10, 27))[0] == 0         # missed a day: reset


def test_ago_wording():
    now = datetime(2026, 1, 1, 12, 0, 0)
    assert [activity.ago(now - timedelta(seconds=s), now) for s in (3, 30, 120, 7200, 200000)] == \
           ["just now", "30s ago", "2m ago", "2h ago", "2d ago"]
