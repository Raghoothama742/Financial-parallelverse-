import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool
from backend.app.database import Base, get_db
import uuid
from backend.app.models import FinancialProfile, ScenarioSimulation, InstallmentPlan, InstallmentPayment, User
from backend.app.services import auth_service
from backend.app.main import app

# In-memory test database with StaticPool so all connections share the same memory instance
SQLALCHEMY_DATABASE_URL = "sqlite:///:memory:"

engine = create_engine(
    SQLALCHEMY_DATABASE_URL,
    connect_args={"check_same_thread": False},
    poolclass=StaticPool
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

@pytest.fixture(scope="session", autouse=True)
def setup_test_db():
    Base.metadata.create_all(bind=engine)
    yield
    Base.metadata.drop_all(bind=engine)

@pytest.fixture(scope="function")
def db_session():
    db = TestingSessionLocal()
    try:
        yield db
    finally:
        db.rollback()
        db.close()

def _override(db_session):
    def override_get_db():
        try:
            yield db_session
        finally:
            pass
    app.dependency_overrides[get_db] = override_get_db


@pytest.fixture(scope="function")
def anon_client(db_session):
    """A client that is NOT signed in."""
    _override(db_session)
    with TestClient(app) as c:
        yield c
    app.dependency_overrides.clear()


@pytest.fixture(scope="function")
def client(db_session):
    """A client signed in as a brand-new user, through the real login flow."""
    _override(db_session)
    user = auth_service.register(db_session, f"{uuid.uuid4().hex[:10]}@example.com", "Test User", "correct-horse-battery")
    token = auth_service.create_session(db_session, user)
    with TestClient(app, headers={"Authorization": f"Bearer {token}"}) as c:
        c.user = user
        yield c
    app.dependency_overrides.clear()
