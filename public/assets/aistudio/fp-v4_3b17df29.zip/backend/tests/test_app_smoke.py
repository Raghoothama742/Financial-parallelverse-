"""
Boots the real Streamlit app and opens every tab.

Runs in a subprocess with PARALLELVERSE_DB pointing at a throwaway database, so it can
never touch the real data file. Catches the things unit tests cannot: syntax errors in
app.py, duplicate widget keys, crashes on an empty database, and broken widgets.
"""
import ast
import json
import subprocess
import sys
import textwrap
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
APP = ROOT / "frontend_streamlit" / "app.py"

pytest.importorskip("streamlit.testing.v1")


def test_app_file_compiles():
    ast.parse(APP.read_text(encoding="utf-8"))


def test_every_rupee_input_hides_pointless_decimals():
    tree = ast.parse(APP.read_text(encoding="utf-8"))
    missing = [
        n.lineno for n in ast.walk(tree)
        if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr == "number_input"
        and n.args and isinstance(n.args[0], ast.Constant) and "₹" in str(n.args[0].value)
        and not any(k.arg == "format" for k in n.keywords)
    ]
    assert not missing, f"rupee inputs without format at lines {missing}"


DRIVER = textwrap.dedent('''
    import json, os, sys
    sys.path.insert(0, {root!r})
    from streamlit.testing.v1 import AppTest
    from backend.app.database import init_db, SessionLocal
    from backend.app.services import auth_service
    init_db()
    db = SessionLocal()
    user = auth_service.register(db, "smoke@example.com", "Smoke Tester", "correct-horse-battery")
    token = auth_service.create_session(db, user)
    db.close()

    APP = {app!r}
    out = {{}}
    def new(page=None, signed_in=True):
        at = AppTest.from_file(APP, default_timeout=90)
        if signed_in:
            at.session_state["token"] = token
        if page:
            at.session_state["pvnav"] = page
        at.run()
        return at
    def errs(at): return [str(e.value) for e in at.exception]

    # ---- signed out: landing page + real sign-in flows
    at = new(signed_in=False)
    out["landing"] = errs(at)
    out["landing_has_signin"] = [t.label for t in at.tabs][:2] == ["Sign in", "Create account"]
    out["landing_hides_app"] = not any("Left over each month" in str(h.value) for h in at.get("html"))

    at = new(signed_in=False)
    at.text_input[0].set_value("smoke@example.com"); at.text_input[1].set_value("totally-wrong-pw")
    [b for b in at.button if b.label == "Sign in"][0].click().run()
    out["wrong_pw_shows_error"] = [e.value for e in at.error] == ["Wrong email or password."]
    out["wrong_pw_stays_out"] = "uid" not in at.session_state

    at = new(signed_in=False)
    at.text_input[0].set_value("smoke@example.com"); at.text_input[1].set_value("correct-horse-battery")
    [b for b in at.button if b.label == "Sign in"][0].click().run()
    out["login_ok"] = errs(at) + ([] if "uid" in at.session_state else ["not signed in"])

    at = new(signed_in=False)
    at.text_input(key="reg_name").set_value("New Person"); at.text_input(key="reg_email").set_value("new@example.com")
    at.text_input(key="reg_pw").set_value("another-good-phrase"); at.text_input(key="reg_pw2").set_value("another-good-phrase")
    at.button(key="reg_btn").click().run()
    out["register_ok"] = errs(at) + ([] if "uid" in at.session_state else ["not signed in"])

    at = new(signed_in=False)
    at.text_input(key="reg_email").set_value("new@example.com"); at.text_input(key="reg_pw").set_value("another-good-phrase")
    at.text_input(key="reg_pw2").set_value("different-phrase-here"); at.button(key="reg_btn").click().run()
    out["register_mismatch_blocked"] = [e.value for e in at.error] == ["The two passwords do not match."]

    at = new(signed_in=False)
    at.button(key="guest_btn").click().run()
    out["guest_ok"] = errs(at) + ([] if "uid" in at.session_state else ["not signed in"])

    # ---- signed in: every tab
    for page in ["home", "buy", "whatif", "emis", "me"]:
        out[page] = errs(new(page))
    at = new("buy")
    for opt in ["buy_cash_now", "save_and_wait", "cheaper_alternative", "buy_via_emi"]:
        at.session_state["buy_option"] = opt; at.run()
        out["buy:" + opt] = errs(at)
    at = new("whatif")
    for view in ["flow", "balance"]:
        at.session_state["whatif_view"] = view; at.run()
        out["whatif:" + view] = errs(at)

    # ---- log out really signs you out
    at = new("home")
    at.button(key="logout_btn").click().run()
    out["logout_ok"] = errs(at) + (["still signed in"] if "uid" in at.session_state else [])
    out["logout_back_on_landing"] = [t.label for t in at.tabs][:2] == ["Sign in", "Create account"]
    print("RESULT" + json.dumps(out))
''')


@pytest.fixture(scope="module")
def smoke_results(tmp_path_factory):
    db = tmp_path_factory.mktemp("smoke") / "fresh.db"      # brand-new, empty database
    env = {**__import__("os").environ, "PARALLELVERSE_DB": str(db)}
    proc = subprocess.run(
        [sys.executable, "-c", DRIVER.format(root=str(ROOT), app=str(APP))],
        env=env, capture_output=True, text=True, timeout=240, cwd=str(ROOT))
    line = next((l for l in proc.stdout.splitlines() if l.startswith("RESULT")), None)
    assert line, f"driver produced no result.\nstdout: {proc.stdout[-800:]}\nstderr: {proc.stderr[-1500:]}"
    return json.loads(line[len("RESULT"):])


@pytest.mark.parametrize("key", [
    "landing", "login_ok", "register_ok", "guest_ok", "logout_ok",
    "home", "buy", "whatif", "emis", "me",
    "buy:buy_cash_now", "buy:save_and_wait", "buy:cheaper_alternative", "buy:buy_via_emi",
    "whatif:flow", "whatif:balance",
])
def test_page_renders_without_exceptions(smoke_results, key):
    assert smoke_results[key] == [], smoke_results[key]


@pytest.mark.parametrize("key", [
    "landing_has_signin", "landing_hides_app", "wrong_pw_shows_error", "wrong_pw_stays_out",
    "register_mismatch_blocked", "logout_back_on_landing",
])
def test_auth_behaviour(smoke_results, key):
    assert smoke_results[key] is True
