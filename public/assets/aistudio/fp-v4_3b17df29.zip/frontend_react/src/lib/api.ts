const BASE_URL = 'http://localhost:8000/api';

export const api = {
  async getProfile() {
    const res = await fetch(`${BASE_URL}/profile`);
    if (!res.ok) throw new Error('Failed to fetch profile');
    return res.json();
  },

  async updateProfile(data: any) {
    const res = await fetch(`${BASE_URL}/profile`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error('Failed to update profile');
    return res.json();
  },

  async simulateScenarios(payload: any) {
    const res = await fetch(`${BASE_URL}/scenarios/simulate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    if (!res.ok) throw new Error('Failed to run simulation');
    return res.json();
  },

  async evaluatePurchase(payload: any) {
    const res = await fetch(`${BASE_URL}/purchases/evaluate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    if (!res.ok) throw new Error('Failed to evaluate purchase');
    return res.json();
  },

  async calculateEMI(payload: any) {
    const res = await fetch(`${BASE_URL}/emi/calculate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    if (!res.ok) throw new Error('Failed to calculate EMI');
    return res.json();
  },

  async getInstallments() {
    const res = await fetch(`${BASE_URL}/installments`);
    if (!res.ok) throw new Error('Failed to fetch installments');
    return res.json();
  },

  async createInstallment(data: any) {
    const res = await fetch(`${BASE_URL}/installments`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error('Failed to create installment');
    return res.json();
  },

  async updatePaymentStatus(planId: number, paymentId: number, status: string) {
    const res = await fetch(`${BASE_URL}/installments/${planId}/payments/${paymentId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status }),
    });
    if (!res.ok) throw new Error('Failed to update payment');
    return res.json();
  },

  async deleteInstallment(planId: number) {
    const res = await fetch(`${BASE_URL}/installments/${planId}`, {
      method: 'DELETE',
    });
    if (!res.ok) throw new Error('Failed to delete installment');
    return res.json();
  }
};
