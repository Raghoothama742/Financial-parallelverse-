"""
Small, dependency-free HTML building blocks for the Parallelverse UI.

Nothing here imports Streamlit, so every function can be unit-tested. All user-supplied
text is escaped before it reaches the HTML. Styling lives in pv_theme.py (classes `pv-*`).
"""
from __future__ import annotations

from datetime import date
from html import escape as esc
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

# --------------------------------------------------------------------------- copy
# Plain-English names for the five simulated futures (the engine keeps its own ids).
FUTURES: Dict[str, Tuple[str, str, str]] = {
    "baseline": ("🌤️", "Smooth sailing", "Everything goes to plan."),
    "unexpected_expense": ("🧾", "Surprise bill", "A sudden medical or repair cost hits."),
    "delayed_salary": ("⏳", "Late salary", "Your pay turns up late."),
    "increased_spending": ("📈", "Prices go up", "Everyday costs creep higher."),
    "combined_adverse": ("⛈️", "Perfect storm", "All three happen at once."),
}
FUTURE_COLORS: Dict[str, str] = {
    "baseline": "#00C48C",
    "unexpected_expense": "#FF7A1A",
    "delayed_salary": "#00B8E6",
    "increased_spending": "#B44CFF",
    "combined_adverse": "#FF3366",
}
RISK_COPY: Dict[str, Tuple[str, str]] = {
    "LOW": ("Safe", "good"),
    "MODERATE": ("Okay", "info"),
    "HIGH": ("Risky", "warn"),
    "CRITICAL": ("Danger", "bad"),
}
RATING_COPY: Dict[str, Tuple[str, str]] = {
    "SAFE": ("Safe", "good"),
    "CAUTION": ("Be careful", "warn"),
    "HIGH_RISK": ("Risky", "bad"),
}
OPTION_COPY: Dict[str, Tuple[str, str]] = {
    "buy_cash_now": ("💵", "Pay cash now"),
    "save_and_wait": ("⏳", "Save first, buy later"),
    "cheaper_alternative": ("🪙", "Pick the cheaper one"),
    "buy_via_emi": ("💳", "Pay in EMIs"),
}
# What each part of the money-health score asks the user to do.
HEALTH_ACTIONS: Dict[str, str] = {
    "saving_habit": "Save a bit more each month",
    "safety_net": "Grow your safety net",
    "debt_load": "Pay down your EMIs",
    "emergency_fund": "Top up your emergency fund",
}


# --------------------------------------------------------------------------- numbers
def _group_indian(whole: str) -> str:
    """'1234567' -> '12,34,567' (lakh/crore grouping)."""
    if len(whole) <= 3:
        return whole
    head, tail = whole[:-3], whole[-3:]
    parts: List[str] = []
    while len(head) > 2:
        parts.append(head[-2:])
        head = head[:-2]
    if head:
        parts.append(head)
    return ",".join(reversed(parts)) + "," + tail


def inr(value: Optional[float], decimals: int = 0) -> str:
    """Rupee amount with Indian digit grouping, e.g. inr(120000) -> '₹1,20,000'."""
    try:
        v = float(value)
    except (TypeError, ValueError):
        v = 0.0
    if v != v:  # NaN
        v = 0.0
    text = f"{abs(v):.{decimals}f}"
    whole, _, frac = text.partition(".")
    out = _group_indian(whole) + (f".{frac}" if frac else "")
    is_zero = float(text) == 0.0
    return ("-" if v < 0 and not is_zero else "") + "₹" + out


def pct(value: Optional[float], decimals: int = 0) -> str:
    try:
        return f"{float(value):.{decimals}f}%"
    except (TypeError, ValueError):
        return "0%"


def months_text(m: float) -> str:
    """3.0 -> '3 months', 1.5 -> '1.5 months', 1 -> '1 month', 99 -> '8+ years'."""
    if m >= 96:
        return "8+ years"
    shown = f"{m:.1f}".rstrip("0").rstrip(".")
    return f"{shown} month" + ("" if shown == "1" else "s")


def greeting(hour: int) -> str:
    if 5 <= hour < 12:
        return "Good morning"
    if 12 <= hour < 17:
        return "Good afternoon"
    if 17 <= hour < 21:
        return "Good evening"
    return "Hey night owl"


def days_label(due: date, today: date) -> str:
    delta = (due - today).days
    if delta == 0:
        return "due today"
    if delta == 1:
        return "due tomorrow"
    if delta > 1:
        return f"due in {delta} days"
    late = -delta
    return f"{late} day{'s' if late != 1 else ''} late"


def score_tone(score: int) -> str:
    if score >= 80:
        return "good"
    if score >= 60:
        return "info"
    if score >= 40:
        return "warn"
    return "bad"


def biggest_boost(breakdown: Dict[str, Dict[str, float]]) -> Tuple[str, float]:
    """The part of the money-health score with the most points still on the table."""
    gaps = {k: v["max"] - v["points"] for k, v in breakdown.items()}
    key = max(gaps, key=lambda k: gaps[k])
    return HEALTH_ACTIONS.get(key, "Keep going"), round(gaps[key])


# --------------------------------------------------------------------------- verdicts
def verdict_for(option_id: str, wait_months: int = 4) -> Tuple[str, str, str]:
    """(tone, icon, headline) for the recommended buying option."""
    if option_id == "buy_cash_now":
        return "good", "✅", "Go for it. You can pay cash."
    if option_id == "buy_via_emi":
        return "info", "💳", "Go for it, but pay in EMIs."
    if option_id == "cheaper_alternative":
        return "info", "🪙", "Pick the cheaper option."
    return "warn", "⏳", f"Wait about {wait_months} months."


# --------------------------------------------------------------------------- blocks
def section(title: str, sub: str = "") -> str:
    sub_html = f'<div class="pv-section-sub">{esc(sub)}</div>' if sub else ""
    return f'<div class="pv-section"><div class="pv-section-title">{esc(title)}</div>{sub_html}</div>'


def pill(text: str, tone: str = "muted") -> str:
    return f'<span class="pv-pill pv-t-{esc(tone)}">{esc(text)}</span>'


def stat(label: str, value: str, sub: str = "", tone: str = "brand", icon: str = "", unit: str = "") -> str:
    """A big-number tile."""
    unit_html = f'<span class="pv-stat-unit">{esc(unit)}</span>' if unit else ""
    sub_html = f'<div class="pv-stat-sub">{esc(sub)}</div>' if sub else ""
    icon_html = f'<span class="pv-stat-icon">{esc(icon)}</span>' if icon else ""
    return (
        f'<div class="pv-card pv-stat pv-accent-{esc(tone)}">'
        f'<div class="pv-stat-label"><span>{esc(label)}</span>{icon_html}</div>'
        f'<div class="pv-stat-value pv-c-{esc(tone)}">{esc(value)}{unit_html}</div>'
        f"{sub_html}</div>"
    )


def banner(tone: str, icon: str, title: str, body: str = "") -> str:
    body_html = f'<div class="pv-banner-body">{esc(body)}</div>' if body else ""
    return (
        f'<div class="pv-banner pv-b-{esc(tone)}">'
        f'<div class="pv-banner-icon">{esc(icon)}</div>'
        f'<div><div class="pv-banner-title">{esc(title)}</div>{body_html}</div></div>'
    )


def meter(value: float, maximum: float, tone: str = "brand") -> str:
    share = 0.0 if maximum <= 0 else max(0.0, min(100.0, value / maximum * 100.0))
    return (
        f'<div class="pv-meter"><div class="pv-meter-fill pv-f-{esc(tone)}" style="width:{share:.1f}%"></div></div>'
    )


def ring(score: int, label: str, tone: str) -> str:
    """Circular 0-100 gauge, drawn with CSS (Streamlit's sanitiser strips inline <svg>)."""
    score = int(max(0, min(100, score)))
    return (
        '<div class="pv-ring-wrap">'
        f'<div class="pv-ring pv-t-{esc(tone)}" style="--p:{score}" role="img" '
        f'aria-label="Money health {score} out of 100, {esc(label)}">'
        f'<div class="pv-ring-inner"><div class="pv-ring-num">{score}</div>'
        '<div class="pv-ring-of">out of 100</div></div></div></div>'
    )


def split_bar(segments: Sequence[Tuple[str, float, str]]) -> str:
    """Stacked horizontal bar + legend. segments = [(label, amount, tone), ...]."""
    total = sum(max(0.0, v) for _, v, _ in segments)
    if total <= 0:
        return '<div class="pv-muted">Add your income and expenses to see where your money goes.</div>'
    bar = "".join(
        f'<div class="pv-split-seg pv-f-{esc(t)}" style="width:{max(0.0, v) / total * 100:.2f}%" '
        f'title="{esc(lbl)}: {esc(inr(v))}"></div>'
        for lbl, v, t in segments
        if v > 0
    )
    legend = "".join(
        f'<div class="pv-legend-item"><span class="pv-dot pv-f-{esc(t)}"></span>'
        f'<span class="pv-legend-label">{esc(lbl)}</span>'
        f'<span class="pv-legend-val">{esc(inr(v))}</span></div>'
        for lbl, v, t in segments
    )
    return f'<div class="pv-split">{bar}</div><div class="pv-legend">{legend}</div>'


def option_card(opt: Dict, recommended: bool) -> str:
    icon, title = OPTION_COPY.get(opt["option_id"], ("🛍️", opt["option_title"]))
    rating_text, rating_tone = RATING_COPY.get(opt["risk_rating"], ("Check", "muted"))
    ribbon = '<div class="pv-ribbon">⭐ Best fit</div>' if recommended else ""
    kept = opt["emergency_buffer_preserved_pct"]
    kept_tone = "good" if kept >= 100 else ("warn" if kept >= 50 else "bad")
    monthly = (
        f'{esc(inr(opt["monthly_obligation"]))}<span class="pv-unit">/month</span>'
        if opt["monthly_obligation"] > 0
        else '<span class="pv-c-muted">None</span>'
    )
    return (
        f'<div class="pv-card pv-option{" pv-recommended" if recommended else ""}">'
        f"{ribbon}"
        f'<div class="pv-option-head"><span class="pv-option-icon">{icon}</span>'
        f'<span class="pv-option-title">{esc(title)}</span></div>'
        f"{pill(rating_text, rating_tone)}"
        '<div class="pv-kv-list">'
        f'<div class="pv-kv"><span>Pay today</span><b>{esc(inr(opt["upfront_cash_required"]))}</b></div>'
        f'<div class="pv-kv"><span>Every month</span><b>{monthly}</b></div>'
        f'<div class="pv-kv"><span>Total you will pay</span><b>{esc(inr(opt["total_cost"]))}</b></div>'
        f'<div class="pv-kv"><span>Safety net kept</span><b class="pv-c-{kept_tone}">{kept:.0f}%</b></div>'
        "</div>"
        f'<div class="pv-option-note">{esc(opt["key_tradeoff"])}</div>'
        "</div>"
    )


def future_card(scenario_id: str, data: Dict) -> str:
    emoji, name, blurb = FUTURES.get(scenario_id, ("🔮", data.get("scenario_name", scenario_id), ""))
    risk_text, risk_tone = RISK_COPY.get(data["risk_level"], ("Check", "muted"))
    if data["negative_cash_months"] > 0 and risk_tone in ("good", "info"):
        # The engine's score can still read "okay" while cash dips below zero; never show that as fine.
        risk_text, risk_tone = "Risky", "warn"
    low = data["lowest_savings"]
    low_tone = "bad" if low < 0 else "text"
    red_months = data["negative_cash_months"]
    red_tone = "bad" if red_months > 0 else "good"
    return (
        f'<div class="pv-card pv-future" style="--pv-future:{FUTURE_COLORS.get(scenario_id, "#6A4BFF")}">'
        f'<div class="pv-future-head"><span class="pv-future-emoji">{emoji}</span>'
        f"{pill(risk_text, risk_tone)}</div>"
        f'<div class="pv-future-name">{esc(name)}</div>'
        f'<div class="pv-future-blurb">{esc(blurb)}</div>'
        '<div class="pv-future-low-label">Lowest balance</div>'
        f'<div class="pv-future-low pv-c-{low_tone}">{esc(inr(low))}</div>'
        '<div class="pv-kv-list pv-kv-small">'
        f'<div class="pv-kv"><span>Strength</span><b>{data["resilience_score"]}/100</b></div>'
        f'<div class="pv-kv"><span>Months in the red</span><b class="pv-c-{red_tone}">{red_months}</b></div>'
        "</div>"
        f'<div class="pv-future-note">{esc(data.get("breaking_point_reason") or "")}</div>'
        "</div>"
    )


def data_table(headers: Sequence[str], rows: Iterable[Sequence[str]], numeric_from: int = 1) -> str:
    """Theme-safe table (st.dataframe is a canvas and ignores our colours)."""
    head = "".join(f"<th>{esc(str(h))}</th>" for h in headers)
    body = []
    for r in rows:
        cells = "".join(
            "<td{}>{}</td>".format(' class="pv-num"' if i >= numeric_from else "", esc(str(c)))
            for i, c in enumerate(r)
        )
        body.append(f"<tr>{cells}</tr>")
    return f'<div class="pv-table-wrap"><table class="pv-table"><thead><tr>{head}</tr></thead><tbody>{"".join(body)}</tbody></table></div>'


def grid(items: Sequence[str], cols: int = 2, extra_class: str = "") -> str:
    return f'<div class="pv-grid pv-cols-{cols} {esc(extra_class)}">{"".join(items)}</div>'


# --------------------------------------------------------------------------- live tracker + auth
def compact_inr(value: float) -> str:
    """₹1.2 Cr / ₹4.5 L / ₹12,000 : short form for big running totals."""
    v = float(value or 0)
    if v >= 1e7:
        return f"₹{v / 1e7:.1f} Cr"
    if v >= 1e5:
        return f"₹{v / 1e5:.1f} L"
    return inr(v)


def live_panel(stats: dict) -> str:
    """The live counters + activity feed. Aggregates only; never names or exact personal figures."""
    tiles = [
        ("Online now", f"{stats['online']:,}", '<span class="pv-pulse"></span>'),
        ("Total visits", f"{stats['visits']:,}", "👁️"),
        ("Members", f"{stats['members']:,}", "👥"),
        ("Purchases analysed", compact_inr(stats["analysed_amount"]), "🧮"),
    ]
    tile_html = "".join(
        f'<div class="pv-live-tile"><div class="pv-live-num">{esc(v)}</div>'
        f'<div class="pv-live-label"><span>{esc(l)}</span>{icon}</div></div>' for l, v, icon in tiles)
    if stats["feed"]:
        feed = "".join(f'<div class="pv-feed-row"><span>{esc(f["text"])}</span><span class="pv-feed-when">{esc(f["when"])}</span></div>'
                       for f in stats["feed"])
    else:
        feed = '<div class="pv-feed-row"><span class="pv-muted">Be the first to make something happen here.</span></div>'
    return (
        '<div class="pv-card pv-live"><div class="pv-live-head"><span class="pv-live-title">'
        '<span class="pv-pulse"></span>Live</span><span class="pv-hint">updates every few seconds</span></div>'
        f'<div class="pv-live-grid">{tile_html}</div><div class="pv-feed">{feed}</div></div>')


def strength_bar(score: int, label: str) -> str:
    tone = ["bad", "bad", "warn", "info", "good"][max(0, min(4, score))]
    if not label:
        return '<div class="pv-strength"></div>'   # never return "": st.html("") raises
    return (f'<div class="pv-strength">{meter(score, 4, tone)}'
            f'<div class="pv-hint">Password strength: <b class="pv-c-{tone}">{esc(label)}</b></div></div>')


def streak_chip(current: int) -> str:
    if current <= 0:
        return '<span class="pv-chip">🌱 Start your streak today</span>'
    return f'<span class="pv-chip">🔥 {current}-day streak</span>'
