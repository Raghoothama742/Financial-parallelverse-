"""
Styling for the Parallelverse UI.

Design rules
------------
* Auto day/night: colours follow the device's light/dark setting (prefers-color-scheme),
  the same signal Streamlit's native widgets use by default. Nothing here hard-codes a mode.
* Every custom card sets its OWN background and text colour, so it stays readable even if
  the user forces a Streamlit theme that differs from the device setting.
* Text that sits on the bare page (titles, hints) inherits Streamlit's colour instead.
* Palette values are checked for WCAG contrast in backend/tests/test_ui_helpers.py.
"""

# Palettes are exported so the contrast test can verify them.
LIGHT = {
    "surface": "#FFFFFF",
    "surface2": "#F3F5FA",
    "text": "#151833",
    "muted": "#555C80",
    "border": "rgba(21, 24, 51, 0.10)",
    "track": "rgba(21, 24, 51, 0.10)",
    "shadow": "0 6px 24px rgba(60, 50, 140, 0.10)",
    "good": "#057A5A",
    "warn": "#8A4F00",
    "bad": "#C8183F",
    "info": "#1558D6",
    "brand": "#3F4FD8",
    "grad_a": "#3F4FD8",
    "grad_b": "#0B7BBF",
    "nav_bg": "rgba(255, 255, 255, 0.92)",
}
DARK = {
    "surface": "#171B29",
    "surface2": "#1F2433",
    "text": "#F2F4FF",
    "muted": "#A3ABCB",
    "border": "rgba(255, 255, 255, 0.09)",
    "track": "rgba(255, 255, 255, 0.12)",
    "shadow": "0 10px 30px rgba(0, 0, 0, 0.35)",
    "good": "#3BE3AE",
    "warn": "#FFC247",
    "bad": "#FF6B88",
    "info": "#7DB0FF",
    "brand": "#9DAEFF",
    "grad_a": "#9DAEFF",
    "grad_b": "#5CC8F5",
    "nav_bg": "rgba(14, 17, 23, 0.92)",
}


def _vars(p: dict) -> str:
    return "\n".join(f"      --pv-{k.replace('_', '-')}: {v};" for k, v in p.items())


def get_css() -> str:
    return f"""
<style>
  :root {{
{_vars(LIGHT)}
  }}
  @media (prefers-color-scheme: dark) {{
    :root {{
{_vars(DARK)}
    }}
  }}

  /* ---------- page shell ---------- */
  [data-testid="stMainBlockContainer"], .block-container {{
    max-width: 1080px;
    padding-top: 1.4rem;
    padding-bottom: 7rem;
  }}
  .stButton button, .stDownloadButton button, .stFormSubmitButton button {{
    border-radius: 12px;
    font-weight: 600;
  }}
  div[data-baseweb="input"], div[data-baseweb="select"] > div, div[data-baseweb="textarea"] {{
    border-radius: 12px;
  }}
  [data-testid="stExpander"] details {{ border-radius: 14px; }}

  /* ---------- tone helpers (text / fill / stroke / accent) ---------- */
  .pv-c-good {{ color: var(--pv-good); }}   .pv-c-warn {{ color: var(--pv-warn); }}
  .pv-c-bad {{ color: var(--pv-bad); }}     .pv-c-info {{ color: var(--pv-info); }}
  .pv-c-brand {{ color: var(--pv-brand); }} .pv-c-muted {{ color: var(--pv-muted); }}
  .pv-c-text {{ color: var(--pv-text); }}
  .pv-f-good {{ background: var(--pv-good); }}   .pv-f-warn {{ background: var(--pv-warn); }}
  .pv-f-bad {{ background: var(--pv-bad); }}     .pv-f-info {{ background: var(--pv-info); }}
  .pv-f-brand {{ background: var(--pv-brand); }} .pv-f-muted {{ background: var(--pv-muted); }}
  .pv-t-good, .pv-b-good {{ --tone: var(--pv-good); }}   .pv-t-warn, .pv-b-warn {{ --tone: var(--pv-warn); }}
  .pv-t-bad, .pv-b-bad {{ --tone: var(--pv-bad); }}      .pv-t-info, .pv-b-info {{ --tone: var(--pv-info); }}
  .pv-t-brand, .pv-b-brand {{ --tone: var(--pv-brand); }} .pv-t-muted, .pv-b-muted {{ --tone: var(--pv-muted); }}
  .pv-accent-good {{ border-top: 4px solid var(--pv-good); }}   .pv-accent-warn {{ border-top: 4px solid var(--pv-warn); }}
  .pv-accent-bad {{ border-top: 4px solid var(--pv-bad); }}     .pv-accent-info {{ border-top: 4px solid var(--pv-info); }}
  .pv-accent-brand {{ border-top: 4px solid var(--pv-brand); }}

  /* ---------- headings (sit on the bare page: inherit colour) ---------- */
  .pv-brand {{
    font-weight: 800; font-size: 1.05rem; letter-spacing: -0.01em;
    display: flex; align-items: center; gap: 8px; margin-bottom: 0.2rem;
  }}
  .pv-logo {{
    width: 30px; height: 30px; border-radius: 10px; display: inline-flex; align-items: center;
    justify-content: center; font-size: 1.05rem;
    background: linear-gradient(135deg, var(--pv-grad-a), var(--pv-grad-b)); color: #fff;
  }}
  .pv-title {{
    font-size: clamp(1.7rem, 4.5vw, 2.4rem); font-weight: 800; line-height: 1.12; letter-spacing: -0.03em;
    background: linear-gradient(120deg, var(--pv-grad-a), var(--pv-grad-b));
    -webkit-background-clip: text; background-clip: text; color: transparent; -webkit-text-fill-color: transparent;
    margin: 0.2rem 0 0.15rem 0;
  }}
  .pv-title-emoji {{ font-size: clamp(1.5rem, 4vw, 2.1rem); margin-left: 8px; vertical-align: 0.05em; }}
  .pv-lead {{ opacity: 0.75; font-size: 1.02rem; margin-bottom: 1rem; }}
  .pv-section {{ margin: 1.6rem 0 0.7rem 0; }}
  .pv-section-title {{ font-size: 1.25rem; font-weight: 800; letter-spacing: -0.02em; }}
  .pv-section-sub {{ opacity: 0.7; font-size: 0.92rem; margin-top: 2px; }}
  .pv-hint {{ opacity: 0.7; font-size: 0.86rem; }}
  .pv-muted {{ opacity: 0.7; }}

  /* ---------- cards ---------- */
  .pv-card {{
    background: var(--pv-surface); color: var(--pv-text);
    border: 1px solid var(--pv-border); border-radius: 18px;
    padding: 1.05rem 1.2rem; box-shadow: var(--pv-shadow);
    transition: transform .18s ease, box-shadow .18s ease;
  }}
  .pv-card:hover {{ transform: translateY(-2px); }}
  .pv-grid {{ display: grid; gap: 14px; margin-bottom: 0.4rem; }}
  .pv-cols-2 {{ grid-template-columns: repeat(2, minmax(0, 1fr)); }}
  .pv-cols-3 {{ grid-template-columns: repeat(3, minmax(0, 1fr)); }}
  .pv-cols-4 {{ grid-template-columns: repeat(4, minmax(0, 1fr)); }}
  .pv-cols-5 {{ grid-template-columns: repeat(5, minmax(0, 1fr)); }}

  .pv-pill {{
    display: inline-block; padding: 3px 11px; border-radius: 999px; font-size: 0.76rem; font-weight: 700;
    color: var(--tone); background: color-mix(in srgb, var(--tone) 12%, var(--pv-surface));
    border: 1px solid color-mix(in srgb, var(--tone) 35%, transparent);
  }}
  .pv-chip {{
    display: inline-block; padding: 4px 12px; margin: 0 6px 6px 0; border-radius: 999px; font-size: 0.82rem;
    font-weight: 600; background: var(--pv-surface2); color: var(--pv-text); border: 1px solid var(--pv-border);
  }}

  /* ---------- stat tile ---------- */
  .pv-stat-label {{
    display: flex; justify-content: space-between; align-items: center;
    font-size: 0.78rem; font-weight: 700; letter-spacing: 0.04em; text-transform: uppercase; color: var(--pv-muted);
  }}
  .pv-stat-icon {{ font-size: 1.1rem; }}
  .pv-stat-value {{ font-size: clamp(1.5rem, 4vw, 2rem); font-weight: 800; letter-spacing: -0.02em; line-height: 1.15; margin-top: 6px; }}
  .pv-stat-unit {{ font-size: 0.95rem; font-weight: 700; margin-left: 4px; color: var(--pv-muted); }}
  .pv-stat-sub {{ font-size: 0.86rem; color: var(--pv-muted); margin-top: 4px; }}

  /* ---------- banner ---------- */
  .pv-banner {{
    display: flex; gap: 14px; align-items: flex-start; padding: 1rem 1.15rem; border-radius: 18px;
    color: var(--pv-text);
    background: color-mix(in srgb, var(--tone) 12%, var(--pv-surface));
    border: 1px solid color-mix(in srgb, var(--tone) 45%, transparent);
    border-left: 6px solid var(--tone); margin: 0.3rem 0 1rem 0;
  }}
  .pv-banner-icon {{ font-size: 1.7rem; line-height: 1.1; }}
  .pv-banner-title {{ font-size: 1.15rem; font-weight: 800; letter-spacing: -0.01em; }}
  .pv-banner-body {{ font-size: 0.96rem; margin-top: 3px; opacity: 0.92; }}

  /* ---------- meters, ring, split bar ---------- */
  .pv-meter {{ height: 10px; border-radius: 999px; background: var(--pv-track); overflow: hidden; }}
  .pv-meter-fill {{ height: 100%; border-radius: 999px; transition: width .4s ease; }}
  .pv-ring-wrap {{ display: flex; justify-content: center; }}
  .pv-ring {{
    --size: 158px; width: var(--size); height: var(--size); border-radius: 50%; position: relative;
    background: conic-gradient(var(--tone) calc(var(--p) * 1%), var(--pv-track) 0);
    display: grid; place-items: center;
  }}
  .pv-ring-inner {{
    width: calc(var(--size) - 26px); height: calc(var(--size) - 26px); border-radius: 50%;
    background: var(--pv-surface); display: flex; flex-direction: column; align-items: center; justify-content: center;
  }}
  .pv-ring-num {{ font-size: 2.5rem; font-weight: 800; line-height: 1; letter-spacing: -0.03em; color: var(--pv-text); }}
  .pv-ring-of {{ font-size: 0.66rem; font-weight: 700; letter-spacing: 0.06em; text-transform: uppercase; color: var(--pv-muted); margin-top: 4px; }}

  .pv-split {{ display: flex; height: 16px; border-radius: 999px; overflow: hidden; gap: 2px; background: var(--pv-track); }}
  .pv-split-seg {{ height: 100%; }}
  .pv-legend {{ display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 8px 18px; margin-top: 14px; }}
  .pv-legend-item {{ display: flex; align-items: center; gap: 8px; font-size: 0.9rem; }}
  .pv-dot {{ width: 10px; height: 10px; border-radius: 50%; flex: none; }}
  .pv-legend-label {{ color: var(--pv-muted); flex: 1; }}
  .pv-legend-val {{ font-weight: 700; }}

  /* ---------- home hero ---------- */
  .pv-hero {{ display: grid; grid-template-columns: 170px 1fr; gap: 20px; align-items: center; }}
  .pv-hero-label {{ font-size: 0.78rem; font-weight: 700; letter-spacing: 0.05em; text-transform: uppercase; color: var(--pv-muted); }}
  .pv-hero-word {{ font-size: clamp(1.6rem, 4vw, 2.1rem); font-weight: 800; letter-spacing: -0.02em; line-height: 1.1; margin: 4px 0 10px 0; }}
  .pv-hero-tip {{
    font-size: 0.92rem; padding: 10px 12px; border-radius: 12px; background: var(--pv-surface2);
    border: 1px solid var(--pv-border);
  }}

  /* ---------- buying options ---------- */
  .pv-option {{ position: relative; display: flex; flex-direction: column; gap: 10px; }}
  .pv-recommended {{ border: 2px solid var(--pv-brand); }}
  .pv-ribbon {{
    position: absolute; top: -12px; right: 14px; padding: 3px 12px; border-radius: 999px; font-size: 0.76rem;
    font-weight: 800; color: #fff; background: linear-gradient(120deg, var(--pv-grad-a), var(--pv-grad-b));
  }}
  .pv-option-head {{ display: flex; align-items: center; gap: 10px; }}
  .pv-option-icon {{ font-size: 1.5rem; }}
  .pv-option-title {{ font-size: 1.1rem; font-weight: 800; letter-spacing: -0.01em; }}
  .pv-kv-list {{ display: flex; flex-direction: column; gap: 8px; border-top: 1px solid var(--pv-border); padding-top: 10px; }}
  .pv-kv {{ display: flex; justify-content: space-between; gap: 10px; font-size: 0.92rem; }}
  .pv-kv span {{ color: var(--pv-muted); }}
  .pv-kv b {{ font-weight: 800; text-align: right; }}
  .pv-kv-small {{ font-size: 0.84rem; }}
  .pv-unit {{ font-size: 0.78rem; font-weight: 600; color: var(--pv-muted); margin-left: 3px; }}
  .pv-option-note {{ font-size: 0.86rem; color: var(--pv-muted); border-top: 1px solid var(--pv-border); padding-top: 10px; }}

  /* ---------- future cards ---------- */
  .pv-future {{ border-top: 4px solid var(--pv-future); display: flex; flex-direction: column; gap: 4px; }}
  .pv-future-head {{ display: flex; justify-content: space-between; align-items: center; }}
  .pv-future-emoji {{ font-size: 1.6rem; }}
  .pv-future-name {{ font-size: 1.05rem; font-weight: 800; margin-top: 4px; }}
  .pv-future-blurb {{ font-size: 0.82rem; color: var(--pv-muted); min-height: 2.3em; }}
  .pv-future-low-label {{ font-size: 0.72rem; font-weight: 700; letter-spacing: 0.05em; text-transform: uppercase; color: var(--pv-muted); margin-top: 8px; }}
  .pv-future-low {{ font-size: 1.45rem; font-weight: 800; letter-spacing: -0.02em; margin-bottom: 6px; }}
  .pv-future-note {{ font-size: 0.78rem; color: var(--pv-muted); border-top: 1px solid var(--pv-border); padding-top: 8px; margin-top: 8px; }}

  /* ---------- list rows (payments, plans) ---------- */
  .pv-row {{
    display: flex; align-items: center; gap: 14px; padding: 12px 14px; border-radius: 14px;
    background: var(--pv-surface); color: var(--pv-text); border: 1px solid var(--pv-border);
  }}
  .pv-row-late {{ border-left: 5px solid var(--pv-bad); }}
  .pv-row-main {{ flex: 1; min-width: 0; }}
  .pv-row-title {{ font-weight: 800; }}
  .pv-row-sub {{ font-size: 0.84rem; color: var(--pv-muted); }}
  .pv-row-amt {{ font-weight: 800; font-size: 1.05rem; white-space: nowrap; }}
  .pv-plan-head {{ display: flex; justify-content: space-between; gap: 12px; flex-wrap: wrap; align-items: flex-start; }}
  .pv-plan-name {{ font-size: 1.2rem; font-weight: 800; letter-spacing: -0.01em; margin: 6px 0 2px 0; }}
  .pv-plan-progress {{ margin-top: 12px; }}
  .pv-plan-progress-label {{ display: flex; justify-content: space-between; font-size: 0.84rem; color: var(--pv-muted); margin-bottom: 6px; }}

  /* ---------- tables ---------- */
  .pv-table-wrap {{
    max-height: 360px; overflow: auto; border-radius: 14px; border: 1px solid var(--pv-border);
    background: var(--pv-surface);
  }}
  .pv-table {{ width: 100%; border-collapse: collapse; font-size: 0.88rem; color: var(--pv-text); }}
  .pv-table th {{
    position: sticky; top: 0; background: var(--pv-surface2); text-align: left; padding: 9px 12px;
    font-size: 0.76rem; letter-spacing: 0.04em; text-transform: uppercase; color: var(--pv-muted);
  }}
  .pv-table td {{ padding: 8px 12px; border-top: 1px solid var(--pv-border); }}
  .pv-table td.pv-num, .pv-table th:not(:first-child) {{ text-align: right; font-variant-numeric: tabular-nums; }}

  /* ---------- navigation (native segmented control, positioned like an app) ---------- */
  .st-key-pvnavbar {{ margin: 0.5rem 0 1.1rem 0; }}
  .st-key-pvnavbar button {{ font-weight: 700; }}


  /* ---------- live tracker ---------- */
  .pv-pulse {{
    display: inline-block; width: 9px; height: 9px; border-radius: 50%; background: var(--pv-good);
    margin-right: 7px; box-shadow: 0 0 0 0 color-mix(in srgb, var(--pv-good) 60%, transparent);
    animation: pv-pulse 1.8s infinite;
  }}
  .pv-live-tile .pv-pulse {{ margin: 0 0 0 6px; }}
  @keyframes pv-pulse {{
    0% {{ box-shadow: 0 0 0 0 color-mix(in srgb, var(--pv-good) 55%, transparent); }}
    70% {{ box-shadow: 0 0 0 9px transparent; }}
    100% {{ box-shadow: 0 0 0 0 transparent; }}
  }}
  .pv-live-head {{ display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; }}
  .pv-live-title {{ font-weight: 800; letter-spacing: 0.04em; text-transform: uppercase; font-size: 0.8rem; display: flex; align-items: center; }}
  .pv-live-grid {{ display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 10px; }}
  .pv-live-tile {{ background: var(--pv-surface2); border: 1px solid var(--pv-border); border-radius: 14px; padding: 10px 12px; }}
  .pv-live-num {{ font-size: 1.5rem; font-weight: 800; letter-spacing: -0.02em; font-variant-numeric: tabular-nums; }}
  .pv-live-label {{ font-size: 0.74rem; color: var(--pv-muted); display: flex; align-items: center; justify-content: space-between; font-weight: 600; }}
  .pv-feed {{ margin-top: 12px; display: flex; flex-direction: column; gap: 6px; }}
  .pv-feed-row {{ display: flex; justify-content: space-between; gap: 10px; font-size: 0.86rem; padding: 6px 2px; border-top: 1px solid var(--pv-border); }}
  .pv-feed-when {{ color: var(--pv-muted); white-space: nowrap; }}
  .pv-strength {{ margin: -4px 0 8px 0; }}
  .pv-landing-hero {{ margin: 0.6rem 0 1rem 0; }}
  .pv-landing-title {{ font-size: clamp(2rem, 6vw, 3.2rem); font-weight: 800; line-height: 1.05; letter-spacing: -0.04em; }}
  .pv-userbar {{ display: flex; justify-content: flex-end; align-items: center; gap: 8px; flex-wrap: wrap; }}
  @media (max-width: 640px) {{
    .pv-live-grid {{ grid-template-columns: repeat(2, minmax(0, 1fr)); }}
    .pv-userbar {{ justify-content: flex-start; }}
  }}


  /* ---------- vibrant layer ---------- */
  .stApp {{
    background:
      radial-gradient(900px 520px at 8% -8%, color-mix(in srgb, var(--pv-grad-a) 8%, transparent), transparent 70%),
      radial-gradient(800px 520px at 100% 0%, color-mix(in srgb, var(--pv-grad-b) 6%, transparent), transparent 70%),
      radial-gradient(900px 600px at 50% 110%, color-mix(in srgb, var(--pv-info) 5%, transparent), transparent 70%);
    background-color: var(--background-color, transparent);
  }}
  .pv-card {{ box-shadow: 0 10px 30px color-mix(in srgb, var(--pv-grad-a) 14%, transparent); }}
  .pv-accent-good {{ border-top: 5px solid var(--pv-good); box-shadow: 0 10px 30px color-mix(in srgb, var(--pv-good) 22%, transparent); }}
  .pv-accent-warn {{ border-top: 5px solid var(--pv-warn); box-shadow: 0 10px 30px color-mix(in srgb, var(--pv-warn) 22%, transparent); }}
  .pv-accent-bad {{ border-top: 5px solid var(--pv-bad); box-shadow: 0 10px 30px color-mix(in srgb, var(--pv-bad) 22%, transparent); }}
  .pv-accent-info {{ border-top: 5px solid var(--pv-info); box-shadow: 0 10px 30px color-mix(in srgb, var(--pv-info) 22%, transparent); }}
  .pv-accent-brand {{ border-top: 5px solid var(--pv-brand); box-shadow: 0 10px 30px color-mix(in srgb, var(--pv-brand) 24%, transparent); }}
  .pv-banner {{ background: linear-gradient(110deg, color-mix(in srgb, var(--tone) 20%, var(--pv-surface)), color-mix(in srgb, var(--tone) 6%, var(--pv-surface))); }}
  .pv-chip {{ background: linear-gradient(120deg, color-mix(in srgb, var(--pv-grad-a) 16%, var(--pv-surface)), color-mix(in srgb, var(--pv-grad-b) 16%, var(--pv-surface))); border-color: color-mix(in srgb, var(--pv-grad-a) 35%, transparent); }}
  .pv-ring {{ filter: drop-shadow(0 6px 16px color-mix(in srgb, var(--tone) 45%, transparent)); }}
  .pv-live-tile {{ background: linear-gradient(135deg, color-mix(in srgb, var(--pv-grad-a) 14%, var(--pv-surface)), color-mix(in srgb, var(--pv-grad-b) 10%, var(--pv-surface))); }}
  .pv-future {{ box-shadow: 0 10px 30px color-mix(in srgb, var(--pv-future) 26%, transparent); }}
  /* gradient primary buttons + selected tab (white text on vivid fill) */
  .stButton button[kind="primary"], .stFormSubmitButton button[kind="primary"], .stDownloadButton button[kind="primary"] {{
    background: linear-gradient(120deg, #4458E6, #1F78D1); color: #fff; border: none;
    box-shadow: 0 6px 18px rgba(63, 79, 216, 0.28);
  }}
  .stButton button[kind="primary"] p, .stFormSubmitButton button[kind="primary"] p {{ color: #fff; font-weight: 700; }}
  .st-key-pvnavbar [role="radio"][aria-checked="true"] {{
    background: linear-gradient(120deg, #4458E6, #1F78D1); border-color: transparent;
  }}
  .st-key-pvnavbar [role="radio"][aria-checked="true"] p {{ color: #fff; font-weight: 800; }}

  /* ---------- responsive ---------- */
  @media (max-width: 900px) {{
    .pv-cols-3, .pv-cols-4, .pv-cols-5 {{ grid-template-columns: repeat(2, minmax(0, 1fr)); }}
    .pv-cols-5 > :last-child:nth-child(odd) {{ grid-column: 1 / -1; }}
  }}
  @media (max-width: 640px) {{
    .pv-cols-2, .pv-cols-3, .pv-cols-5 {{ grid-template-columns: 1fr; }}
    .pv-cols-4.pv-keep2 {{ grid-template-columns: repeat(2, minmax(0, 1fr)); }}
    .pv-hero {{ grid-template-columns: 1fr; justify-items: center; text-align: center; }}
    .pv-legend {{ grid-template-columns: 1fr; }}
    [data-testid="stMainBlockContainer"], .block-container {{ padding-left: 1rem; padding-right: 1rem; }}
    /* bottom tab bar, like a phone app */
    .st-key-pvnavbar {{
      position: fixed; left: 0; right: 0; bottom: 0; z-index: 999; margin: 0;
      padding: 8px 8px calc(8px + env(safe-area-inset-bottom));
      background: var(--pv-nav-bg); backdrop-filter: blur(14px); -webkit-backdrop-filter: blur(14px);
      border-top: 1px solid var(--pv-border);
    }}
    .st-key-pvnavbar [role="radiogroup"] {{ flex-wrap: nowrap; width: 100%; gap: 2px; }}
    .st-key-pvnavbar [role="radio"] {{ flex: 1 1 0; min-width: 0; padding: 0.4rem 0.1rem; }}
    .st-key-pvnavbar [role="radio"] span[data-has-shortcut] {{ flex-direction: column; gap: 1px; }}
    .st-key-pvnavbar [role="radio"] p {{ font-size: 0.68rem; line-height: 1.15; white-space: nowrap; }}
  }}
  @media (prefers-reduced-motion: reduce) {{
    .pv-card {{ transition: none; }}
    .pv-pulse {{ animation: none; }}
  }}
</style>
"""
