"""
Financial Parallelverse: simple, friendly money app.

Five tabs, plain English, one clear answer on every screen:
  Home        how am I doing, and what is due soon
  Can I buy?  pay cash, wait, pick cheaper, or EMI; with the real cost
  What if?    five possible futures for your savings
  My EMIs     track payments, calculator, calendar reminders
  Me          your numbers and assumptions
"""
import secrets
import sys
import time
from contextlib import contextmanager
from datetime import date, datetime
from pathlib import Path
from zoneinfo import ZoneInfo

import plotly.graph_objects as go
import streamlit as st

ROOT_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT_DIR))

from backend.app.database import SessionLocal, init_db
from backend.app.models import FinancialProfile, InstallmentPayment, InstallmentPlan, User
from backend.app.services import activity, auth_service
from backend.app.services.auth_service import AuthError
from backend.app.services.affordability import AffordabilityPlanner
from backend.app.services.emi_calculator import EMICalculator
from backend.app.services.financial_engine import FinancialEngine
from backend.app.services.reminder_service import ReminderService
from backend.app.services.scenario_engine import ScenarioEngine
from frontend_streamlit import pv_theme, pv_ui
from frontend_streamlit.pv_ui import inr, months_text, pct

init_db()

st.set_page_config(page_title="Parallelverse", page_icon="🌌", layout="wide", initial_sidebar_state="collapsed")
st.html(pv_theme.get_css())

PAGES = {
    "home": "🏠 Home",
    "buy": "🛍️ Can I buy?",
    "whatif": "🔮 What if?",
    "emis": "💳 EMIs",
    "me": "⚙️ Me",
}

PRESETS = {
    "student": dict(
        full_name="Rohan (Student)", monthly_income=25000.0, current_savings=35000.0,
        essential_expenses=14000.0, discretionary_expenses=5000.0, existing_debt_emi=0.0,
        emergency_fund_target=45000.0, income_growth_pct=0.0, investment_return_pct=4.0, credit_score=700,
        planned_purchase_name="Smartphone", planned_purchase_amount=28000.0),
    "techie": dict(
        full_name="Alex (Techie)", monthly_income=75000.0, current_savings=120000.0,
        essential_expenses=32000.0, discretionary_expenses=15000.0, existing_debt_emi=8000.0,
        emergency_fund_target=150000.0, income_growth_pct=8.0, investment_return_pct=6.0, credit_score=750,
        planned_purchase_name="Laptop", planned_purchase_amount=70000.0),
}


# ----------------------------------------------------------------------------- helpers
@contextmanager
def db_session():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def _uid() -> int:
    return st.session_state["uid"]


def load_profile() -> dict:
    """The signed-in user's profile as a plain dict (so nothing depends on a closed DB session)."""
    with db_session() as db:
        p = auth_service.get_or_create_profile(db, db.get(User, _uid()))
        return {c.name: getattr(p, c.name) for c in FinancialProfile.__table__.columns}


def save_profile(values: dict) -> None:
    with db_session() as db:
        p = auth_service.get_or_create_profile(db, db.get(User, _uid()))
        for k, v in values.items():
            setattr(p, k, v)
        p.onboarded = 1
        p.updated_at = datetime.utcnow()
        db.commit()


def metrics_for(p: dict) -> dict:
    return FinancialEngine.calculate_profile_metrics(
        monthly_income=p["monthly_income"], current_savings=p["current_savings"],
        essential_expenses=p["essential_expenses"], discretionary_expenses=p["discretionary_expenses"],
        existing_debt_emi=p["existing_debt_emi"], emergency_fund_target=p["emergency_fund_target"])


def now_local() -> datetime:
    try:
        return datetime.now(ZoneInfo(st.context.timezone or "Asia/Kolkata"))
    except Exception:
        return datetime.now()


def go_to(page: str) -> None:
    st.session_state["pvnav"] = page


def safe_down_payment(price: float, wanted: float) -> float:
    """Down payment must be below the price for the EMI maths to be valid."""
    return float(max(0.0, min(wanted, price - 1.0)))


def lead(title: str, sub: str, emoji: str = "") -> None:
    # The emoji sits outside the gradient text, otherwise it renders as a smudge.
    tail = f'<span class="pv-title-emoji">{emoji}</span>' if emoji else ""
    st.html(f'<div><span class="pv-title">{title}</span>{tail}</div><div class="pv-lead">{sub}</div>')



# ============================================================================= live tracker + accounts
st.session_state.setdefault("sid", secrets.token_hex(16))


def track(kind: str, sig=None, amount=None) -> None:
    """Counts an action for the live feed, at most once per distinct input and once per 10 seconds."""
    last = st.session_state.get("last_track", {})
    now = time.time()
    if sig is not None and last.get(kind, (None, 0))[0] == sig:
        return
    if now - last.get(kind, (None, 0))[1] < 10:
        return
    last[kind] = (sig, now)
    st.session_state["last_track"] = last
    with db_session() as db:
        activity.record(db, kind, st.session_state.get("uid"), amount)


@st.fragment(run_every=8)
def live_panel_fragment():
    """Re-runs by itself every 8 seconds, so the counters tick without touching the rest of the page."""
    with db_session() as db:
        activity.heartbeat(db, st.session_state["sid"], st.session_state.get("uid"))
        stats = activity.live_stats(db)
    st.html(pv_ui.live_panel(stats))


@st.fragment(run_every=20)
def presence():
    """Silent heartbeat so you still count as 'online' while reading."""
    with db_session() as db:
        activity.heartbeat(db, st.session_state["sid"], st.session_state.get("uid"))


def finish_login(token: str, user_id: int) -> None:
    st.session_state["token"], st.session_state["uid"] = token, user_id
    st.query_params["s"] = token          # lets a refresh keep you signed in
    st.rerun()


def sign_out() -> None:
    with db_session() as db:
        auth_service.revoke_session(db, st.session_state.get("token"))
    for k in ("token", "uid", "last_track", "buy_option", "whatif_pick"):
        st.session_state.pop(k, None)
    st.query_params.clear()
    st.rerun()


def resolve_user():
    """Signed-in User from this browser session, or from the ?s= token after a refresh. None if signed out."""
    token = st.session_state.get("token") or st.query_params.get("s")
    with db_session() as db:
        user = auth_service.user_from_token(db, token)
        if not user:
            st.session_state.pop("token", None)
            st.session_state.pop("uid", None)
            return None
        st.session_state["token"], st.session_state["uid"] = token, user.id
        return {"id": user.id, "name": user.name, "email": user.email, "is_guest": user.is_guest}


def render_landing() -> None:
    if not st.session_state.get("visit_logged"):
        with db_session() as db:
            activity.record(db, "visit")
            auth_service.purge_expired(db)
        st.session_state["visit_logged"] = True
    st.html('<div class="pv-brand"><span class="pv-logo">🌌</span>Parallelverse</div>')
    left, right = st.columns([1.15, 1], gap="large")
    with left:
        st.html(
            '<div class="pv-landing-hero"><div class="pv-landing-title"><span class="pv-title">'
            'Know if you can afford it, before you buy it.</span></div>'
            '<div class="pv-lead" style="margin-top:.8rem">Parallelverse tests your next big purchase against five '
            'possible futures, late salary, surprise bills, rising prices, and tells you the safest way to pay.</div></div>')
        st.html("".join(f'<span class="pv-chip">{c}</span>' for c in
                        ["🔮 5 parallel futures", "💳 EMI tracker + reminders", "📊 Credit score estimate",
                         "🛟 Job-loss survival time", "🔥 Daily streaks"]))
        live_panel_fragment()
    with right:
        with st.container(border=True):
            tab_in, tab_up = st.tabs(["Sign in", "Create account"])
            with tab_in:
                with st.form("login_form"):
                    email = st.text_input("Email", autocomplete="email")
                    pw = st.text_input("Password", type="password", autocomplete="current-password")
                    if st.form_submit_button("Sign in", type="primary", width="stretch"):
                        try:
                            with db_session() as db:
                                user = auth_service.authenticate(db, email, pw)
                                token = auth_service.create_session(db, user)
                                uid = user.id
                            finish_login(token, uid)
                        except AuthError as e:
                            st.error(str(e))
            with tab_up:
                name = st.text_input("Your name", key="reg_name", autocomplete="name")
                email_r = st.text_input("Email", key="reg_email", autocomplete="email")
                pw_r = st.text_input("Password", type="password", key="reg_pw", autocomplete="new-password",
                                     help=f"At least {auth_service.MIN_PASSWORD_LEN} characters. A short phrase works well.")
                sc, lb = auth_service.password_strength(pw_r)
                st.html(pv_ui.strength_bar(sc, lb))
                pw2 = st.text_input("Repeat password", type="password", key="reg_pw2", autocomplete="new-password")
                if st.button("Create my account", type="primary", width="stretch", key="reg_btn"):
                    try:
                        if pw_r != pw2:
                            raise AuthError("The two passwords do not match.")
                        with db_session() as db:
                            user = auth_service.register(db, email_r, name, pw_r)
                            token = auth_service.create_session(db, user)
                            uid = user.id
                        finish_login(token, uid)
                    except AuthError as e:
                        st.error(str(e))
            st.html('<div class="pv-hint" style="text-align:center;margin:.2rem 0 .4rem">or</div>')
            if st.button("👀  Try it as a guest, no sign-up", width="stretch", key="guest_btn"):
                with db_session() as db:
                    user = auth_service.create_guest(db)
                    token = auth_service.create_session(db, user)
                    uid = user.id
                finish_login(token, uid)
            st.html('<div class="pv-hint" style="text-align:center">Guest data is deleted after 24 hours. '
                    'Passwords are stored as salted scrypt hashes, never in plain text.</div>')


current_user = resolve_user()
if current_user is None:
    render_landing()
    st.stop()

# Signed in from here on.
if not st.session_state.get("visit_logged"):
    with db_session() as db:
        activity.record(db, "visit", current_user["id"])
    st.session_state["visit_logged"] = True
with db_session() as db:
    today_local = now_local().date()
    activity.record_daily_visit(db, current_user["id"], today_local)
    streak_now, streak_best, days_used = activity.streak(db, current_user["id"], today_local)

# ----------------------------------------------------------------------------- header + nav
profile = load_profile()
metrics = metrics_for(profile)

hb1, hb2, hb3 = st.columns([2.2, 3, 1.2], vertical_alignment="center")
hb1.html('<div class="pv-brand"><span class="pv-logo">🌌</span>Parallelverse</div>')
hb2.html('<div class="pv-userbar">' + pv_ui.streak_chip(streak_now) +
         f'<span class="pv-chip">👤 {current_user["name"][:24]}{" (guest)" if current_user["is_guest"] else ""}</span></div>')
if hb3.button("Log out", key="logout_btn", width="stretch"):
    sign_out()
presence()
with st.container(key="pvnavbar"):
    page = st.segmented_control(
        "Go to", list(PAGES), format_func=PAGES.get, default="home", required=True,
        key="pvnav", label_visibility="collapsed", width="stretch")


# ============================================================================= HOME
if page == "home":
    first_name = (profile["full_name"] or "there").split(" ")[0].strip("()") or "there"
    lead(f"{pv_ui.greeting(now_local().hour)}, {first_name}", "Here is how your money looks today.", "👋")

    score, label = metrics["health_score"], metrics["health_label"]
    tone = pv_ui.score_tone(score)
    action, gap = pv_ui.biggest_boost(metrics["health_breakdown"])
    tip = (f"<b>Easiest win:</b> {action} (up to +{int(gap)} points)." if gap > 0
           else "<b>You are doing great.</b> Keep it up.")
    st.html(
        '<div class="pv-card"><div class="pv-hero">'
        f"{pv_ui.ring(score, label, tone)}"
        '<div><div class="pv-hero-label">Your money health</div>'
        f'<div class="pv-hero-word pv-c-{tone}">{label}</div>'
        f'<div class="pv-hero-tip">{tip}</div></div></div></div>')

    if not profile.get("onboarded", 1):
        st.html(pv_ui.banner("info", "✏️", "These are starter numbers",
                             "Add your own pay, savings and bills so every answer is about you."))
        st.button("Make it mine", on_click=go_to, args=("me",), type="primary", key="onboard_btn")
    leftover_tone = "good" if metrics["free_cash_flow"] >= 0 else "bad"
    goal_pct = metrics["emergency_coverage_pct"]
    dti = metrics["debt_to_income_pct"]
    st.html(pv_ui.grid([
        pv_ui.stat("Left over each month", inr(metrics["free_cash_flow"]),
                   f"You save {pct(metrics['savings_rate_pct'])} of your pay", leftover_tone, "💵"),
        pv_ui.stat("Your savings", inr(profile["current_savings"]),
                   f"{goal_pct:.0f}% of your safety goal", "good" if goal_pct >= 100 else "info", "🏦"),
        pv_ui.stat("Safety net", months_text(metrics["months_of_runway"]),
                   "of must-pay bills covered", "good" if metrics["months_of_runway"] >= 3 else "warn", "🛟"),
        pv_ui.stat("EMI load", pct(dti, 0), "of your pay (aim for under 35%)",
                   "good" if dti <= 20 else ("warn" if dti <= 35 else "bad"), "⚖️"),
    ], 4, "pv-keep2"))

    st.html(pv_ui.section("Where your pay goes"))
    st.html('<div class="pv-card">' + pv_ui.split_bar([
        ("Must-pay bills", profile["essential_expenses"], "info"),
        ("Fun and extras", profile["discretionary_expenses"], "brand"),
        ("Loan EMIs", profile["existing_debt_emi"], "warn"),
        ("Left over", max(0.0, metrics["free_cash_flow"]), "good"),
    ]) + "</div>")

    # Next payment due
    with db_session() as db:
        due = (db.query(InstallmentPayment, InstallmentPlan)
               .join(InstallmentPlan, InstallmentPayment.installment_id == InstallmentPlan.id)
               .filter(InstallmentPlan.user_id == _uid(), InstallmentPlan.status == "ACTIVE", InstallmentPayment.status != "PAID")
               .order_by(InstallmentPayment.due_date).first())
        if due:
            pay, plan = due
            when = pv_ui.days_label(pay.due_date, date.today())
            late = pay.due_date < date.today()
            st.html(pv_ui.section("Next payment"))
            st.html(
                f'<div class="pv-row{" pv-row-late" if late else ""}"><div class="pv-row-main">'
                f'<div class="pv-row-title">{plan.purchase_name}</div>'
                f'<div class="pv-row-sub">EMI {pay.installment_number} of {plan.tenure_months}, {when}</div></div>'
                f'<div class="pv-row-amt">{inr(pay.emi_amount)}</div></div>')

    st.html(pv_ui.section("Your streak", "Open the app each day to keep it alive."))
    st.html(pv_ui.grid([
        pv_ui.stat("Current streak", f"{streak_now}", "days in a row", "warn" if streak_now else "muted", "🔥", unit=" days"),
        pv_ui.stat("Best streak", f"{streak_best}", "your record", "brand", "🏆", unit=" days"),
        pv_ui.stat("Days you checked in", f"{days_used}", "since you joined", "info", "📅"),
    ], 3))
    st.html(pv_ui.section("Right now on Parallelverse", "Anonymous activity from everyone using the app."))
    live_panel_fragment()

    st.html(pv_ui.section("What would you like to do?"))
    c1, c2 = st.columns(2)
    c1.button("🛍️  Can I afford something?", on_click=go_to, args=("buy",), width="stretch", type="primary")
    c2.button("🔮  Test a rough patch", on_click=go_to, args=("whatif",), width="stretch")


# ============================================================================= CAN I BUY IT?
elif page == "buy":
    lead("Can I buy it?", "Tell us what you want. We compare four ways to pay and pick the safest.")

    c1, c2 = st.columns(2)
    item = c1.text_input("What are you buying?", value=profile["planned_purchase_name"] or "Laptop")
    price = c2.number_input("Price (₹)", min_value=1000.0, value=float(max(1000.0, profile["planned_purchase_amount"] or 70000.0)),
                            step=5000.0, format="%.0f")

    with st.expander("Change the details (optional)"):
        a1, a2, a3 = st.columns(3)
        alt_price = a1.number_input("A cheaper option costs (₹)", min_value=500.0, value=float(round(price * 0.6, -3) or 500.0), step=2000.0, format="%.0f")
        wait_m = a2.slider("If I wait, I would wait (months)", 1, 12, 4)
        tenure = a3.selectbox("EMI length (months)", [3, 6, 9, 12, 18, 24], index=3)
        b1, b2 = st.columns(2)
        down = b1.number_input("EMI down payment (₹)", min_value=0.0, max_value=float(price - 1.0),
                               value=safe_down_payment(price, min(10000.0, price * 0.2)), step=2000.0, format="%.0f")
        rate = b2.number_input("EMI interest (% per year)", min_value=0.0, max_value=40.0, value=12.0, step=0.5)

    result = AffordabilityPlanner.evaluate_purchase(
        monthly_income=profile["monthly_income"], current_savings=profile["current_savings"],
        essential_expenses=profile["essential_expenses"], discretionary_expenses=profile["discretionary_expenses"],
        existing_debt_emi=profile["existing_debt_emi"], emergency_fund_target=profile["emergency_fund_target"],
        purchase_name=item, purchase_amount=price, cheaper_alternative_name="the cheaper option",
        cheaper_alternative_amount=alt_price, wait_months=wait_m, emi_down_payment=down,
        emi_interest_rate=rate, emi_tenure_months=tenure)

    track("purchase_check", (item, price), price)
    rec_id = result["recommended_option_id"]
    v_tone, v_icon, v_head = pv_ui.verdict_for(rec_id, wait_m)
    st.html(pv_ui.banner(v_tone, v_icon, v_head, result["verdict_explanation"]))

    st.html(pv_ui.section("Your four options"))
    st.html(pv_ui.grid([pv_ui.option_card(o, o["option_id"] == rec_id) for o in result["options"]], 2))

    # The real cost of the chosen option
    st.html(pv_ui.section("What it really costs you", "Pick an option to see its effect over the next 12 months."))
    option_keys = [o["option_id"] for o in result["options"]]
    chosen = st.segmented_control(
        "Option", option_keys, default=rec_id, required=True, key="buy_option", label_visibility="collapsed",
        format_func=lambda k: " ".join(pv_ui.OPTION_COPY[k]))

    mode, amount = {"buy_cash_now": ("CASH", price), "cheaper_alternative": ("CASH", alt_price),
                    "buy_via_emi": ("EMI", price)}.get(chosen, ("NONE", price))
    sim = ScenarioEngine.simulate_all_scenarios(
        duration_months=12, monthly_income=profile["monthly_income"], current_savings=profile["current_savings"],
        essential_expenses=profile["essential_expenses"], discretionary_expenses=profile["discretionary_expenses"],
        existing_debt_emi=profile["existing_debt_emi"], emergency_fund_target=profile["emergency_fund_target"],
        purchase_name=item, purchase_amount=amount, purchase_mode=mode, emi_down_payment=down,
        emi_interest_rate=rate, emi_tenure_months=tenure, income_growth_pct=profile["income_growth_pct"],
        investment_return_pct=profile["investment_return_pct"], credit_score=profile["credit_score"])
    s, credit = sim["comparison_summary"], sim["comparison_summary"]["credit_impact"]

    if mode == "NONE":
        st.html(pv_ui.banner("info", "⏳", "Nothing is spent today",
                             f"If you wait, you keep all your savings. Come back in {wait_m} months and check again."))
    else:
        runway_drop = s["job_loss_runway_before_months"] - s["job_loss_runway_after_months"]
        rw_tone = "good" if s["job_loss_runway_after_months"] >= 3 else ("warn" if s["job_loss_runway_after_months"] >= 1.5 else "bad")
        cr_tone = "good" if credit["score_at_purchase"] >= credit["current_score"] - 5 else "warn"
        st.html(pv_ui.grid([
            pv_ui.stat("Real cost in 12 months", inr(s["true_cost_of_purchase"]),
                       f"Includes {inr(s['opportunity_cost'])} of growth you give up" if s["opportunity_cost"] > 0
                       else "Cash paid out over the year", "info", "🧾"),
            pv_ui.stat("If your pay stopped", months_text(s["job_loss_runway_after_months"]),
                       f"You could cover bills for {months_text(s['job_loss_runway_before_months'])} before this"
                       + (f" (−{runway_drop:.1f})" if runway_drop > 0.05 else ""), rw_tone, "🛟"),
            pv_ui.stat("EMI load after buying", pct(s["dti_after_purchase_pct"], 0),
                       "of your pay (aim for under 35%)",
                       "good" if s["dti_after_purchase_pct"] <= 20 else ("warn" if s["dti_after_purchase_pct"] <= 35 else "bad"), "⚖️"),
            pv_ui.stat("Credit score", f"{credit['score_at_purchase']}",
                       credit["headline"], cr_tone, "📊"),
        ], 4, "pv-keep2"))
        if credit["has_new_loan"]:
            st.html(f'<div class="pv-hint">Missing even one EMI could drop your score to about '
                    f'<b>{credit["score_if_emi_missed"]}</b>. Credit numbers are estimates, not your real bureau score.</div>')


# ============================================================================= WHAT IF?
elif page == "whatif":
    lead("What if things go wrong?", "We run your next months five different ways, so you know your limits before life tests them.")

    c1, c2, c3 = st.columns(3)
    pay_mode = c1.segmented_control("How will you pay?", ["EMI", "CASH", "NONE"], default="EMI", required=True,
                                    format_func={"EMI": "💳 EMIs", "CASH": "💵 Cash", "NONE": "🚫 No purchase"}.get)
    price = c2.number_input("Purchase price (₹)", min_value=1000.0, step=5000.0,
                            value=float(max(1000.0, profile["planned_purchase_amount"] or 70000.0)), format="%.0f")
    shock = c3.number_input("Surprise bill (₹)", min_value=0.0, value=25000.0, step=5000.0, format="%.0f")

    with st.expander("More controls (optional)"):
        m1, m2, m3 = st.columns(3)
        horizon = m1.slider("Look ahead (months)", 6, 36, 12)
        shock_month = m2.slider("Surprise bill hits in month", 1, horizon, min(3, horizon))
        late_months = m3.slider("Salary is late by (months)", 0, 3, 1)
        n1, n2, n3 = st.columns(3)
        late_start = n1.slider("Salary goes late in month", 1, horizon, min(2, horizon))
        inflation = n2.slider("Prices rise by (%)", 0, 40, 15, 5)
        tenure = n3.selectbox("EMI length (months)", [3, 6, 9, 12, 18, 24], index=3)
        o1, o2, o3 = st.columns(3)
        down = o1.number_input("EMI down payment (₹)", min_value=0.0, max_value=float(price - 1.0),
                               value=safe_down_payment(price, min(10000.0, price * 0.2)), step=2000.0, format="%.0f")
        rate = o2.number_input("EMI interest (% per year)", min_value=0.0, max_value=40.0, value=12.0, step=0.5)
        growth = o3.number_input("Yearly raise (%)", min_value=0.0, max_value=50.0, value=float(profile["income_growth_pct"]), step=1.0)
        ret = st.number_input("Yearly growth on your savings (%)", min_value=0.0, max_value=30.0,
                              value=float(profile["investment_return_pct"]), step=0.5)

    sim = ScenarioEngine.simulate_all_scenarios(
        duration_months=horizon, monthly_income=profile["monthly_income"], current_savings=profile["current_savings"],
        essential_expenses=profile["essential_expenses"], discretionary_expenses=profile["discretionary_expenses"],
        existing_debt_emi=profile["existing_debt_emi"], emergency_fund_target=profile["emergency_fund_target"],
        purchase_name=profile["planned_purchase_name"], purchase_amount=price, purchase_month=1, purchase_mode=pay_mode,
        emi_down_payment=down, emi_interest_rate=rate, emi_tenure_months=tenure,
        unexpected_expense_amount=shock, unexpected_expense_month=shock_month,
        salary_delay_months=late_months, salary_delay_start_month=late_start, expense_increase_pct=float(inflation),
        income_growth_pct=growth, investment_return_pct=ret, credit_score=profile["credit_score"])
    futures = sim["scenarios"]
    track("simulation", (pay_mode, price, shock))

    # Judge by the real balances, not the engine's score label (a score can read "okay" while cash goes negative).
    lowest_name, lowest_future = min(futures.items(), key=lambda kv: kv[1]["lowest_savings"])
    lowest = lowest_future["lowest_savings"]
    goal = profile["emergency_fund_target"]
    where = pv_ui.FUTURES[lowest_name][1].lower()
    if lowest < 0:
        n_red = sum(1 for f in futures.values() if f["negative_cash_months"] > 0)
        st.html(pv_ui.banner("bad", "🚨", "You could run out of money",
                             f"In {n_red} of 5 futures your balance dips below zero. The lowest is {inr(lowest)} "
                             f"({where}). Consider paying less upfront, or build a bigger cushion first."))
    elif lowest < goal:
        st.html(pv_ui.banner("warn", "⚠️", "You stay afloat, but your cushion gets thin",
                             f"Your balance never goes below zero, but it drops to {inr(lowest)} ({where}), "
                             f"under your {inr(goal)} safety goal."))
    else:
        st.html(pv_ui.banner("good", "🛡️", "You are covered in every future",
                             f"Even in the worst case ({where}) you keep at least {inr(lowest)}, above your safety goal."))

    st.html(pv_ui.section("How your savings move"))
    view = st.segmented_control("View", ["balance", "flow"], default="balance", required=True, key="whatif_view",
                                format_func={"balance": "Savings balance", "flow": "Monthly cash flow"}.get,
                                label_visibility="collapsed")
    fig = go.Figure()
    for sid, f in futures.items():
        months = [t["month"] for t in f["timeline"]]
        name = pv_ui.FUTURES[sid][1]
        color = pv_ui.FUTURE_COLORS[sid]
        if view == "balance":
            fig.add_trace(go.Scatter(x=months, y=[t["closing_savings"] for t in f["timeline"]], name=name, mode="lines",
                                     line=dict(color=color, width=4 if sid in ("baseline", "combined_adverse") else 2.5, shape="spline"),
                                     hovertemplate=f"<b>{name}</b><br>Month %{{x}}: ₹%{{y:,.0f}}<extra></extra>"))
        else:
            fig.add_trace(go.Bar(x=months, y=[t["net_cash_flow"] for t in f["timeline"]], name=name, marker_color=color,
                                 hovertemplate=f"<b>{name}</b><br>Month %{{x}}: ₹%{{y:,.0f}}<extra></extra>"))
    if view == "balance":
        fig.add_hline(y=profile["emergency_fund_target"], line_dash="dash", line_color="#F59E0B",
                      annotation_text="Safety goal", annotation_position="top left")
    fig.add_hline(y=0, line_color="#F43F5E", line_width=2)
    fig.update_layout(barmode="group", margin=dict(l=0, r=0, t=10, b=0), height=380, hovermode="x unified",
                      xaxis_title="Month", yaxis_title=None, legend=dict(orientation="h", y=-0.22, x=0.5, xanchor="center"))
    st.plotly_chart(fig, width="stretch", config={"displayModeBar": False})

    st.html(pv_ui.section("The five futures"))
    st.html(pv_ui.grid([pv_ui.future_card(sid, f) for sid, f in futures.items()], 5))

    with st.expander("See the month-by-month numbers"):
        pick = st.segmented_control("Future", list(futures), default="combined_adverse", required=True, key="whatif_pick",
                                    format_func=lambda k: f"{pv_ui.FUTURES[k][0]} {pv_ui.FUTURES[k][1]}")
        rows = [[f"Month {t['month']}", inr(t["income_received"]), inr(t["total_outflows"]),
                 inr(t["interest_earned"]), inr(t["closing_savings"])] for t in futures[pick]["timeline"]]
        st.html(pv_ui.data_table(["Month", "Money in", "Money out", "Growth", "Savings left"], rows))


# ============================================================================= MY EMIs
elif page == "emis":
    lead("My EMIs", "Keep track of what you owe, mark payments as done, and get calendar reminders.")
    tab_plans, tab_calc = st.tabs(["📅 My payments", "🧮 EMI calculator"])

    with tab_plans, db_session() as db:
        with st.expander("➕ Add a new EMI"):
            with st.form("new_plan_form"):
                f1, f2, f3 = st.columns(3)
                new_name = f1.text_input("What is it for?", value="New phone")
                new_cat = f1.selectbox("Type", ["Electronics", "Vehicles", "Education", "Appliances", "Furniture", "Other"])
                new_tot = f2.number_input("Price (₹)", min_value=1000.0, value=65000.0, step=2000.0, format="%.0f")
                new_down = f2.number_input("Paid upfront (₹)", min_value=0.0, value=15000.0, step=2000.0, format="%.0f")
                new_rate = f3.number_input("Interest (% per year)", min_value=0.0, max_value=40.0, value=12.0, step=0.5)
                new_ten = f3.number_input("Months to pay", min_value=1, max_value=60, value=12, step=1)
                new_due = st.slider("Due on this day of the month", 1, 28, 5)
                if st.form_submit_button("Add EMI", type="primary"):
                    if new_down >= new_tot:
                        st.error("The upfront payment must be less than the price.")
                    else:
                        calc, pays = ReminderService.generate_installment_schedule(
                            purchase_name=new_name, total_amount=new_tot, down_payment=new_down,
                            annual_interest_rate=new_rate, tenure_months=int(new_ten), start_date=date.today(), due_day=new_due)
                        plan = InstallmentPlan(
                            user_id=_uid(), purchase_name=new_name, category=new_cat, total_amount=new_tot, down_payment=new_down,
                            principal_financed=calc["principal_financed"], annual_interest_rate=new_rate,
                            tenure_months=int(new_ten), monthly_emi=calc["monthly_emi"], total_repayment=calc["total_repayment"],
                            total_interest=calc["total_interest"], start_date=date.today(), due_day=new_due, status="ACTIVE")
                        db.add(plan)
                        db.flush()
                        for p in pays:
                            db.add(InstallmentPayment(
                                installment_id=plan.id, installment_number=p["installment_number"], due_date=p["due_date"],
                                emi_amount=p["emi_amount"], principal_portion=p["principal_portion"],
                                interest_portion=p["interest_portion"], remaining_balance=p["remaining_balance"],
                                status=p["status"], notes=p["notes"]))
                        db.commit()
                        st.rerun()

        plans = db.query(InstallmentPlan).filter(InstallmentPlan.user_id == _uid()).order_by(InstallmentPlan.id).all()
        for pl in plans:
            ReminderService.update_overdue_statuses(pl.payments, date.today())
        db.commit()

        if not plans:
            st.html(pv_ui.banner("info", "🎉", "No EMIs right now", "Add one above and we will track every payment for you."))
        else:
            active = [p for p in plans if p.status == "ACTIVE"]
            owed = sum(x.emi_amount for p in active for x in p.payments if x.status != "PAID")
            st.html(pv_ui.grid([
                pv_ui.stat("You pay every month", inr(sum(p.monthly_emi for p in active)), f"across {len(active)} EMI(s)", "info", "💳"),
                pv_ui.stat("Still to pay", inr(owed), "in total, including interest", "brand", "🧮"),
            ], 2))

        for pl in plans:
            paid = sum(1 for x in pl.payments if x.status == "PAID")
            total = len(pl.payments)
            late = [x for x in pl.payments if x.status == "OVERDUE"]
            tone = "bad" if late else ("good" if paid == total and total else "info")
            status_txt = f"{len(late)} late" if late else ("All paid 🎉" if paid == total and total else "On track")
            st.html(
                f'<div class="pv-card pv-accent-{tone}" style="margin-top:14px"><div class="pv-plan-head"><div>'
                f'{pv_ui.pill(pl.category, "muted")} {pv_ui.pill(status_txt, tone)}'
                f'<div class="pv-plan-name">{pl.purchase_name}</div>'
                f'<div class="pv-row-sub">{inr(pl.monthly_emi)} a month, due on the {pl.due_day}th</div></div>'
                f'<div style="text-align:right"><div class="pv-stat-label">Paid</div>'
                f'<div class="pv-stat-value pv-c-{tone}">{paid}<span class="pv-stat-unit">of {total}</span></div></div></div>'
                f'<div class="pv-plan-progress"><div class="pv-plan-progress-label"><span>Progress</span>'
                f'<span>{(paid / total * 100 if total else 0):.0f}%</span></div>{pv_ui.meter(paid, total, tone)}</div></div>')

            b1, b2, _ = st.columns([1.4, 1, 2])
            b1.download_button("📅 Add reminders to my calendar", data=ReminderService.generate_ics_calendar(pl.purchase_name, pl.payments),
                               file_name=f"{pl.purchase_name.replace(' ', '_')}_reminders.ics", mime="text/calendar",
                               key=f"ics_{pl.id}", width="stretch")
            confirm_key = f"confirm_del_{pl.id}"
            if st.session_state.get(confirm_key):
                st.warning(f"Delete **{pl.purchase_name}** and all its payments?")
                y, n, _ = st.columns([1, 1, 3])
                if y.button("Yes, delete", key=f"yes_{pl.id}", type="primary"):
                    db.delete(pl)
                    db.commit()
                    st.session_state.pop(confirm_key, None)
                    st.rerun()
                if n.button("Keep it", key=f"no_{pl.id}"):
                    st.session_state.pop(confirm_key, None)
                    st.rerun()
            elif b2.button("🗑️ Delete", key=f"del_{pl.id}", width="stretch"):
                st.session_state[confirm_key] = True
                st.rerun()

            with st.expander(f"Payments for {pl.purchase_name}"):
                for x in pl.payments:
                    r1, r2, r3, r4 = st.columns([1, 2, 1.5, 1.5], vertical_alignment="center")
                    r1.markdown(f"**#{x.installment_number}**")
                    r2.markdown(f"{x.due_date.strftime('%d %b %Y')}  \n<span class='pv-hint'>{pv_ui.days_label(x.due_date, date.today()) if x.status != 'PAID' else 'paid'}</span>",
                                unsafe_allow_html=True)
                    r3.markdown(f"**{inr(x.emi_amount, 2)}**")
                    if x.status != "PAID":
                        if r4.button("Mark paid", key=f"pay_{x.id}", type="primary" if x.status == "OVERDUE" else "secondary"):
                            x.status, x.paid_at = "PAID", datetime.utcnow()
                            db.commit()
                            activity.record(db, "emi_paid", _uid(), x.emi_amount)
                            st.rerun()
                    elif r4.button("Undo", key=f"undo_{x.id}"):
                        x.status, x.paid_at = "PENDING", None
                        db.commit()
                        st.rerun()

    with tab_calc:
        e1, e2 = st.columns(2)
        price = e1.number_input("Price (₹)", min_value=1000.0, value=70000.0, step=5000.0, key="calc_price", format="%.0f")
        down = e2.number_input("Pay upfront (₹)", min_value=0.0, max_value=float(price - 1.0), value=safe_down_payment(price, 10000.0), step=2000.0, key="calc_down", format="%.0f")
        e3, e4 = st.columns(2)
        rate = e3.number_input("Interest (% per year)", min_value=0.0, max_value=40.0, value=12.0, step=0.5, key="calc_rate")
        tenure = e4.slider("Months to pay", 1, 60, 12, key="calc_tenure")
        extra = st.number_input("Pay extra each month to finish sooner (₹)", min_value=0.0, value=0.0, step=500.0, format="%.0f")

        emi = EMICalculator.calculate_emi(price, down, rate, int(tenure), extra)
        saved_note = ""
        if extra > 0:
            base = EMICalculator.calculate_emi(price, down, rate, int(tenure), 0.0)
            saved = base["total_interest"] - emi["total_interest"]
            saved_note = f"Paying extra finishes in {len(emi['schedule'])} months and saves {inr(saved)} of interest."
        st.html(pv_ui.grid([
            pv_ui.stat("You pay each month", inr(emi["monthly_emi"]), f"for {len(emi['schedule'])} months", "brand", "💳"),
            pv_ui.stat("Interest you pay", inr(emi["total_interest"]), saved_note or "The cost of borrowing", "warn", "🔥"),
            pv_ui.stat("You borrow", inr(emi["principal_financed"]), "after your upfront payment", "info", "🏷️"),
            pv_ui.stat("You pay back", inr(emi["total_repayment"]), "in total", "good", "💰"),
        ], 4, "pv-keep2"))
        with st.expander("See every payment"):
            st.html(pv_ui.data_table(
                ["Month", "You pay", "Towards the item", "Interest", "Still owed"],
                [[r["month"], inr(r["payment_amount"], 2), inr(r["principal_paid"], 2), inr(r["interest_paid"], 2),
                  inr(r["remaining_balance"], 2)] for r in emi["schedule"]]))


# ============================================================================= ME
else:
    lead("Me", "Your numbers power every answer. Keep them current and the advice stays accurate.")

    st.html(pv_ui.section("Your account"))
    if current_user["is_guest"]:
        st.html(pv_ui.banner("warn", "⏳", "You are using a guest account",
                             "Guest data is deleted after 24 hours. Log out and choose Create account to keep your numbers."))
    else:
        st.html(f'<div class="pv-card"><div class="pv-row-title">{current_user["name"]}</div>'
                f'<div class="pv-row-sub">{current_user["email"]}</div></div>')
        with st.expander("Change password"):
            with st.form("pw_form"):
                cur = st.text_input("Current password", type="password")
                new = st.text_input("New password", type="password")
                if st.form_submit_button("Update password", type="primary"):
                    try:
                        with db_session() as db:
                            auth_service.change_password(db, db.get(User, _uid()), cur, new)
                        st.session_state.pop("token", None)
                        st.query_params.clear()
                        st.success("Password updated. Please sign in again.")
                        st.rerun()
                    except AuthError as e:
                        st.error(str(e))
    with st.expander("Delete my account and data"):
        st.html('<div class="pv-hint">This permanently removes your profile, EMIs and sign-ins. It cannot be undone.</div>')
        if st.session_state.get("confirm_delete_account"):
            y, n, _ = st.columns([1.2, 1, 3])
            if y.button("Yes, delete everything", type="primary", key="del_acc_yes"):
                with db_session() as db:
                    auth_service.delete_account(db, db.get(User, _uid()))
                for k in ("token", "uid", "confirm_delete_account"):
                    st.session_state.pop(k, None)
                st.query_params.clear()
                st.rerun()
            if n.button("Keep my account", key="del_acc_no"):
                st.session_state.pop("confirm_delete_account", None)
                st.rerun()
        elif st.button("Delete my account", key="del_acc"):
            st.session_state["confirm_delete_account"] = True
            st.rerun()

    st.html(pv_ui.section("Quick start", "Not sure what to enter? Try an example."))
    p1, p2, _ = st.columns([1, 1, 2])
    if p1.button("🎓 Student example", width="stretch"):
        save_profile(PRESETS["student"])
        st.rerun()
    if p2.button("💼 Working example", width="stretch"):
        save_profile(PRESETS["techie"])
        st.rerun()

    with st.form("profile_form"):
        name = st.text_input("Your name", value=profile["full_name"])
        st.html(pv_ui.section("Money in and saved"))
        a1, a2, a3 = st.columns(3)
        income = a1.number_input("Monthly pay after tax (₹)", min_value=0.0, value=float(profile["monthly_income"]), step=5000.0, format="%.0f")
        savings = a2.number_input("Savings today (₹)", min_value=0.0, value=float(profile["current_savings"]), step=10000.0, format="%.0f")
        goal = a3.number_input("Safety goal (₹)", min_value=0.0, value=float(profile["emergency_fund_target"]), step=10000.0,
                               help="A good goal is 3 to 6 months of must-pay bills.", format="%.0f")
        st.html(pv_ui.section("Money out each month"))
        b1, b2, b3 = st.columns(3)
        ess = b1.number_input("Must-pay bills (₹)", min_value=0.0, value=float(profile["essential_expenses"]), step=2000.0,
                              help="Rent, food, transport, medicine, utilities.", format="%.0f")
        disc = b2.number_input("Fun and extras (₹)", min_value=0.0, value=float(profile["discretionary_expenses"]), step=2000.0,
                               help="Eating out, shopping, subscriptions.", format="%.0f")
        debt = b3.number_input("Loan EMIs you already pay (₹)", min_value=0.0, value=float(profile["existing_debt_emi"]), step=1000.0, format="%.0f")
        st.html(pv_ui.section("Looking ahead", "These make forecasts realistic. The defaults are fine to start with."))
        c1, c2, c3 = st.columns(3)
        growth = c1.number_input("Expected raise each year (%)", min_value=0.0, max_value=50.0, value=float(profile["income_growth_pct"]), step=1.0,
                                 help="Your pay steps up by this much every 12 months.")
        ret = c2.number_input("Growth on your savings (% a year)", min_value=0.0, max_value=30.0, value=float(profile["investment_return_pct"]), step=0.5,
                              help="What your savings earn in a deposit or fund. Used to show what spending really costs you.")
        score = c3.number_input("Credit score", min_value=300, max_value=900, value=int(profile["credit_score"]), step=10,
                                help="Check it free on your bank app. We use it to estimate how an EMI could change it.")
        st.html(pv_ui.section("What you are thinking of buying"))
        d1, d2 = st.columns(2)
        buy_name = d1.text_input("Item", value=profile["planned_purchase_name"])
        buy_price = d2.number_input("Price (₹)", min_value=0.0, value=float(profile["planned_purchase_amount"]), step=5000.0, format="%.0f")

        if st.form_submit_button("💾 Save", type="primary", width="stretch"):
            save_profile(dict(
                full_name=name or "Me", monthly_income=income, current_savings=savings, emergency_fund_target=goal,
                essential_expenses=ess, discretionary_expenses=disc, existing_debt_emi=debt, income_growth_pct=growth,
                investment_return_pct=ret, credit_score=int(score), planned_purchase_name=buy_name, planned_purchase_amount=buy_price))
            st.toast("Saved ✅")
            st.rerun()

    st.html('<div class="pv-hint" style="margin-top:1rem">Everything stays on your device in a local database. '
            'The app follows your device\'s light or dark setting, so it turns dark at night by itself.</div>')
